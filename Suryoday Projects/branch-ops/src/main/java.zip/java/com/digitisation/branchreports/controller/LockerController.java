package com.digitisation.branchreports.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.model.LockerMaster;
import com.digitisation.branchreports.service.BranchUserMakerService;
import com.digitisation.branchreports.service.LockerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class LockerController {
	
	@Autowired
	private LockerService lockerservice;
	

	@PostMapping("/getalllocker")
	public List<LockerMaster> getallreports() {

		return lockerservice.getalllocker();
	}	
	
	@PostMapping("/addlocker")
	public LockerMaster addlocker(@RequestBody LockerMaster lm) {
		

		return lockerservice.addlocker(lm);
	}	
}
