package com.digitisation.branchreports.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class DocumentMaster implements Serializable {
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue (strategy=GenerationType.AUTO)
	private long documentId;
	private String documentName;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "center_document_master_id")
	@JsonIgnoreProperties("documentMaster")
	private CenterDocumentMaster centerDocumentMaster;
	
	public CenterDocumentMaster getCenterDocumentMaster() {
		return centerDocumentMaster;
	}

	public void setCenterDocumentMaster(CenterDocumentMaster centerDocumentMaster) {
		this.centerDocumentMaster = centerDocumentMaster;
	}

	public DocumentMaster() {}

	public long getDocumentId() {
		return documentId;
	}

	public void setDocumentId(long documentId) {
		this.documentId = documentId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

		
	}
	
	

