package com.digitisation.branchreports.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class LoanAccounts implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long accountId;

	private String dwAccountId;
	private String branchCode;
	private String branchName;
	private String stateName;
	private String dwRegion;

	private String dwName;
	private String dwCenterId;
	private String dwCenter;
	private String dwClientId;
	private String dwCreditOfficer;
	private Date dwDisbDate;
	private Double dwDisbAmount;
	private String dwAppFileNo;
	private String product;
	private String status;
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	private String remarks;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "batch_id")
	@JsonIgnoreProperties("batch")
	private Batch batch;


//	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name = "loan_doc_id",nullable = false)
//	@JsonIgnoreProperties("loanAccounts")
//	private LoanDocuments loanDocuments;

	public LoanAccounts() {
	}

	public long getAccountId() {
		return accountId;
	}

	public void setAccountId(long accountId) {
		this.accountId = accountId;
	}

	
	public String getDwAccountId() {
		return dwAccountId;
	}

	public void setDwAccountId(String dwAccountId) {
		this.dwAccountId = dwAccountId;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getDwRegion() {
		return dwRegion;
	}

	public void setDwRegion(String dwRegion) {
		this.dwRegion = dwRegion;
	}

	public String getDwName() {
		return dwName;
	}

	public void setDwName(String dwName) {
		this.dwName = dwName;
	}

	public String getDwCenterId() {
		return dwCenterId;
	}

	public void setDwCenterId(String dwCenterId) {
		this.dwCenterId = dwCenterId;
	}

	public String getDwCenter() {
		return dwCenter;
	}

	public void setDwCenter(String dwCenter) {
		this.dwCenter = dwCenter;
	}

	public String getDwClientId() {
		return dwClientId;
	}

	public void setDwClientId(String dwClientId) {
		this.dwClientId = dwClientId;
	}

	public String getDwCreditOfficer() {
		return dwCreditOfficer;
	}

	public void setDwCreditOfficer(String dwCreditOfficer) {
		this.dwCreditOfficer = dwCreditOfficer;
	}

	public Date getDwDisbDate() {
		return dwDisbDate;
	}

	public void setDwDisbDate(Date dwDisbDate) {
		this.dwDisbDate = dwDisbDate;
	}

	public Double getDwDisbAmount() {
		return dwDisbAmount;
	}

	public void setDwDisbAmount(Double dwDisbAmount) {
		this.dwDisbAmount = dwDisbAmount;
	}

	public String getDwAppFileNo() {
		return dwAppFileNo;
	}

	public void setDwAppFileNo(String dwAppFileNo) {
		this.dwAppFileNo = dwAppFileNo;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Batch getBatch() {
		return batch;
	}

	public void setBatch(Batch batch) {
		this.batch = batch;
	}

}
