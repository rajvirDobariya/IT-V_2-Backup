package com.digitisation.branchreports.controller;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.LoginDetails;
import com.digitisation.branchreports.service.LoginService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LoginController {
	
	@Autowired
	private LoginService loginService;

	public LoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}

	@PostMapping("api/login")
	public LoginDetails getLoginDetails(@RequestBody LoginDetails loginDetails) {
		System.out.println(loginDetails.getUserName()+"    "+loginDetails.getPassWord());
		return loginService.getToken(loginDetails.getUserName(),loginDetails.getPassWord());
	}
}
