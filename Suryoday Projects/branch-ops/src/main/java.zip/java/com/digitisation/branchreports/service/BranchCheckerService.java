package com.digitisation.branchreports.service;

import java.util.List;

import com.digitisation.branchreports.model.BranchChecker;
import com.digitisation.branchreports.model.BranchUserMakerModel;

public interface BranchCheckerService {

	public BranchChecker addreport(BranchChecker reportmas);
	
	public List<BranchUserMakerModel> getreports(BranchUserMakerModel reportmas);


}
