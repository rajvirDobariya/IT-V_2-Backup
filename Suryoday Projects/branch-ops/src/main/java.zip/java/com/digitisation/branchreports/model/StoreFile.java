package com.digitisation.branchreports.model;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

public class StoreFile {
	

	private String reportname;
	private MultipartFile uploadFile;
	private String branchname;
	
	
	@Override
	public String toString() {
		return "StoreFile [reportname=" + reportname + ", uploadFile=" + uploadFile + ", branchname=" + branchname
				+ "]";
	}
	
	
	public StoreFile(String reportname, MultipartFile uploadFile, String branchname) {
		super();
		this.reportname = reportname;
		this.uploadFile = uploadFile;
		this.branchname = branchname;
	}
	public String getReportname() {
		return reportname;
	}
	public void setReportname(String reportname) {
		this.reportname = reportname;
	}
	public MultipartFile getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(MultipartFile uploadFile) {
		this.uploadFile = uploadFile;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	
	
}
