package com.digitisation.branchreports.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.CenterDocuments;




	@Repository
	public interface CenterDocumentDataRepository extends JpaRepository<CenterDocuments, Long> {


}
