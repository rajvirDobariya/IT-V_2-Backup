package com.digitisation.branchreports.service;

import java.util.Optional;

import com.digitisation.branchreports.model.CenterDocuments;

public interface CenterDocumentService {
	
	public Optional<CenterDocuments> getCenterDocumentById(CenterDocuments centerDocuments);
	

 
}
