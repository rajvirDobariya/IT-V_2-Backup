package com.digitisation.branchreports.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.model.LoanAccountsData;
import com.digitisation.branchreports.model.LoanDocuments;

@Repository
public interface LoanAccountsRepository extends JpaRepository<LoanAccounts, Long> {
	
	@Query("SELECT b FROM LoanAccounts b WHERE b.dwAccountId = :dwAccountId") 
	List<LoanAccounts> getBatchByAcId(String dwAccountId);




}
