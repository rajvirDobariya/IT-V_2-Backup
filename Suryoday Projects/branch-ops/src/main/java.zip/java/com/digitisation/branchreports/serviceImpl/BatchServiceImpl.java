package com.digitisation.branchreports.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.repository.AccountsRepository;
import com.digitisation.branchreports.repository.BatchRepository;
import com.digitisation.branchreports.service.BatchService;

@Service
@Transactional
public class BatchServiceImpl implements BatchService {
	
	@Autowired
	private BatchRepository batchRepository;
	
	@Autowired
	private AccountsRepository accountRepository;
	
	@Autowired
	public void setBatchRepository(BatchRepository batchRepository) {
		this.batchRepository = batchRepository;
	}
	
	@Override
	public Batch createBatch(Batch batch) {
		return batchRepository.save(batch);
	}

	@Override
	public List<Batch> getAllBatches(String centerId,String createdBy) {
		return batchRepository.findAllBatchForUser(centerId,createdBy);
	}

	@Override
	public Optional<Batch> getBatchById(long id) {
		Optional<Batch> batch = null;
		try {
			batch = batchRepository.findById(id); 
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return batch;
	}

	@Override
	public void deleteBatchById() {
		// TODO Auto-generated method stub

	}

	@Override
	public Batch updateBatch(Batch batch) {
		return batchRepository.saveAndFlush(batch);
	}

	@Override
	public List<Batch> getBatchByCreatedBy(String createdBy) {
		return batchRepository.getBatchByCreatedBy(createdBy);
	}

	@Override
	public List<Batch> getBatchPendingForApproval(String centerId) {
		return batchRepository.getBatchForApproval(centerId);
	}

	@Override
	public List<Batch> getAllApprovedBatch(String status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Batch> getBatchForProcessing() {
		return batchRepository.getBatchForProcessing();
	}

	@Override
	public List<Batch> getBatchForDispath() {
		return batchRepository.getBatchForDispatch();
	}

	@Override
	public List<Batch> getBatchForApproval(String centerId) {
		return batchRepository.getBatchForApproval(centerId);
	}

	@Override
	public List<Batch> getBatchForDescrepancy(String centerId) {
		return batchRepository.getBatchForDescrepancy( centerId);
	}

	@Override
	public List<Batch> getBatchForRetrieval(String centerId) {
		// TODO Auto-generated method stub
		return batchRepository.getBatchForRetrieval(centerId );
	}
	

	@Override
	public List<Batch> getBatchForRetrieval1(String centerId,long batchId) {
		// TODO Auto-generated method stub
		return batchRepository.getBatchForRetrieval1(centerId ,batchId);
	}

//	@Override
//	public List<Batch> getBatchForRetrieval(String centerId, String batchId) {
//		// TODO Auto-generated method stub
//		return batchRepository.getBatchForRetrieval( centerId ,batchId);
//	}

//	@Override
//	public LoanAccounts updateBatch1(LoanAccounts loanAccounts) {
//		return batchRepository.updateStatus(loanAccounts);
//	}
//	@Override
//	public Batch updateBatch(Batch batch) {
//		return batchRepository.saveAndFlush(batch);
//	}
	

//	@Override
//	public List<Batch> updateStatus(long batchId, String dwAccountId, String status) {
//		// TODO Auto-generated method stub
//		return batchRepository.updateStatus(batchId,dwAccountId,status);
//	}

	

}
