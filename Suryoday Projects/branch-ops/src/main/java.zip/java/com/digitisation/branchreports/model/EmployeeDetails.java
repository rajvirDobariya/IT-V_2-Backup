package com.digitisation.branchreports.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
public class EmployeeDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long empDetailsId;
	
	private String empId;
	private String empName;
	private String brachCode;
	private String branchName;
	private String permissions;
	
	@OneToMany(cascade = CascadeType.PERSIST,fetch = FetchType.EAGER)
	@JoinColumn(name = "emp_details_id")
	@JsonIgnoreProperties("employeeDetails")
	private List<EmployeeRole> role =new ArrayList<>();

	
	public long getEmpDetailsId() {
		return empDetailsId;
	}

	public void setEmpDetailsId(long empDetailsId) {
		this.empDetailsId = empDetailsId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getBrachCode() {
		return brachCode;
	}

	public void setBrachCode(String brachCode) {
		this.brachCode = brachCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getPermissions() {
		return permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public List<EmployeeRole> getRole() {
		return role;
	}

	
	public void setRole(List<EmployeeRole> role) {
		this.role = role;
	}
	

}
