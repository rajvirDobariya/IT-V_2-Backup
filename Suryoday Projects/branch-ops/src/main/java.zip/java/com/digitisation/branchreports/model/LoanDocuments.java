package com.digitisation.branchreports.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class LoanDocuments implements Serializable{
	
	/**
	 * Loan Documents capture while creating batch
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long loanDocumentId;
	
	private String fileName;
	private String accountId;
	private String fileType;
	String documentName;
	

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	@Lob
	@Column(name="`FILE`")
	private byte[] fileOne;
	
	
	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}





	public LoanDocuments() {
		
	}
		
	public LoanDocuments(String fileName,String fileType, byte[] file, String accountId ,String documentName) {
			this.fileName = fileName;
			this.fileType = fileType;
			this.fileOne = file;
			this.accountId = accountId;
			this.documentName = documentName;
			
		}

	
	



	
	
			
	
	public long getLoanDocumentId() {
		return loanDocumentId;
	}

	
	public byte[] getFileOne() {
		return fileOne;
	}

	public void setFileOne(byte[] file) {
		this.fileOne = file;
	}

	public void setLoanDocumentId(long loanDocumentId) {
		this.loanDocumentId = loanDocumentId;
	}



	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}


	
//	public UpdateDocument getUpdateDocument() {
//		return updateDocument;
//	}
//
//
//	public void setUpdateDocument(UpdateDocument updateDocument) {
//		this.updateDocument = updateDocument;
//	}


	

	
}

//public Boolean getLoanConsentFormApplicant() {
//return loanConsentFormApplicant;
//}
//
//public void setLoanConsentFormApplicant(Boolean loanConsentFormApplicant) {
//this.loanConsentFormApplicant = loanConsentFormApplicant;
//}
//
//public Boolean getLoanConsentFormGuarantor() {
//return loanConsentFormGuarantor;
//}
//
//public void setLoanConsentFormGuarantor(Boolean loanConsentFormGuarantor) {
//this.loanConsentFormGuarantor = loanConsentFormGuarantor;
//}
//
//public Boolean getDpn() {
//return dpn;
//}
//
//public void setDpn(Boolean dpn) {
//this.dpn = dpn;
//}
//
//public Boolean getAadharCardApplicant() {
//return aadharCardApplicant;
//}
//
//public void setAadharCardApplicant(Boolean aadharCardApplicant) {
//this.aadharCardApplicant = aadharCardApplicant;
//}
//
//public Boolean getPanApplicant() {
//return panApplicant;
//}
//
//public void setPanApplicant(Boolean panApplicant) {
//this.panApplicant = panApplicant;
//}
//
//public Boolean getForm60Applicant() {
//return form60Applicant;
//}
//
//public void setForm60Applicant(Boolean form60Applicant) {
//this.form60Applicant = form60Applicant;
//}
//
//public Boolean getAadharCardGuarantor() {
//return aadharCardGuarantor;
//}
//
//public void setAadharCardGuarantor(Boolean aadharCardGuarantor) {
//this.aadharCardGuarantor = aadharCardGuarantor;
//}
//
//public Boolean getPanGuarantor() {
//return panGuarantor;
//}
//
//public void setPanGuarantor(Boolean panGuarantor) {
//this.panGuarantor = panGuarantor;
//}
//
//public Boolean getForm60Guarantor() {
//return form60Guarantor;
//}
//
//public void setForm60Guarantor(Boolean form60Guarantor) {
//this.form60Guarantor = form60Guarantor;
//}
//
//public Boolean getBankPassbook() {
//return bankPassbook;
//}
//
//public void setBankPassbook(Boolean bankPassbook) {
//this.bankPassbook = bankPassbook;
//}
//
//public Boolean getLifeInsuranceForm() {
//return lifeInsuranceForm;
//}
//
//public void setLifeInsuranceForm(Boolean lifeInsuranceForm) {
//this.lifeInsuranceForm = lifeInsuranceForm;
//}
//
//public Boolean getHospitalFormApplicant() {
//return hospitalFormApplicant;
//}
//
//public void setHospitalFormApplicant(Boolean hospitalFormApplicant) {
//this.hospitalFormApplicant = hospitalFormApplicant;
//}
//
//public Boolean getHospitalFormGuarantor() {
//return hospitalFormGuarantor;
//}
//
//public void setHospitalFormGuarantor(Boolean hospitalFormGuarantor) {
//this.hospitalFormGuarantor = hospitalFormGuarantor;
//}

//
//	public Boolean getCliDocumentOfApplicant() {
//		return cliDocumentOfApplicant;
//	}
//
//
//	public void setCliDocumentOfApplicant(Boolean cliDocumentOfApplicant) {
//		this.cliDocumentOfApplicant = cliDocumentOfApplicant;
//	}
//	
	
//

//	
