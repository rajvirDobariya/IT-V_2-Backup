package com.digitisation.branchreports.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController 
@RequestMapping(value ="/upload")

public class MultiFileUploadController {

private static String UPLOADED_FOLDER = "D://uploadedfiles//";

//@RequestMapping(value = "/singleFileUpload ", method = RequestMethod.POST)
//public String uploadSingleFile(@RequestParam("description") String description,@RequestParam("file") MultipartFile file) {
//
//             String status="";
//        if (!file.isEmpty()) {
//            try {
//            byte[] bytes = file.getBytes();
//            File dir = new File(UPLOADED_FOLDER);    
//            if (!dir.exists())
//                    dir.mkdirs();
//
//
//                File uploadFile = new File(dir.getAbsolutePath()+ File.separator + 
//                                         file.getOriginalFilename());
//                BufferedOutputStream outputStream = new BufferedOutputStream(
//                                new FileOutputStream(uploadFile));
//                outputStream.write(bytes);
//                outputStream.close();
//
//                status = status +  " Successfully uploaded file=" + file.getOriginalFilename();
//            } catch (Exception e) {
//                status = status +  "Failed to upload " + file.getOriginalFilename()+ " " + e.getMessage();
//            }
//        }
//return status; 
//    }
//
//    @RequestMapping(value = "/uploadMultipleFiles ", method =RequestMethod.POST)
//public  String uploadMultipleFiles(@RequestParam("description") String[] descriptions,@RequestParam("file") MultipartFile[] files) {
//
//        if (files.length != descriptions.length)
//            return "Mismatching no of files are equal to description";
//
//        String status = "";
//        File dir = new File(UPLOADED_FOLDER);
//        for (int i = 0; i < files.length; i++) {
//            MultipartFile file = files[i];
//            String description = descriptions[i];
//            try {
//                byte[] bytes = file.getBytes();
//
//                if (!dir.exists())
//                    dir.mkdirs();
//
//                File uploadFile = new File(dir.getAbsolutePath()
//                        + File.separator + file.getOriginalFilename());
//                BufferedOutputStream outputStream = new BufferedOutputStream(
//                        new FileOutputStream(uploadFile));
//                outputStream.write(bytes);
//                outputStream.close();
//
//                status = status + "You successfully uploaded file=" + file.getOriginalFilename();
//            } catch (Exception e) {
//                status = status + "Failed to upload " + file.getOriginalFilename()+ " " + e.getMessage();
//            }
//        }
//        return status;
//    }
}