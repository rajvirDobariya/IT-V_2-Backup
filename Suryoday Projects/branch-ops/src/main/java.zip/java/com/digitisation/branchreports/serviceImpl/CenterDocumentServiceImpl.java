package com.digitisation.branchreports.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.CenterDocuments;
import com.digitisation.branchreports.repository.CenterDocumentDataRepository;
import com.digitisation.branchreports.service.CenterDocumentService;

@Service
public class CenterDocumentServiceImpl implements CenterDocumentService {
	@Autowired
	private CenterDocumentDataRepository centerDocumentDataRepository;

	@Override
	public Optional<CenterDocuments> getCenterDocumentById(CenterDocuments centerDocuments) {
		Optional<CenterDocuments> batch = null;
		try {
			batch = centerDocumentDataRepository.findById(centerDocuments.getCenterDocumentId()); 
		}catch(Exception e) {
			e.printStackTrace();
		}
	return batch;
	}
}
