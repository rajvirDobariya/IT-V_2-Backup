package com.digitisation.branchreports.service;

import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.LoginDetails;

@Service
public interface LoginService {

//	LoginDetails getToken(LoginDetails loginDetails);

	LoginDetails getToken(String userName, String passWord);

}
