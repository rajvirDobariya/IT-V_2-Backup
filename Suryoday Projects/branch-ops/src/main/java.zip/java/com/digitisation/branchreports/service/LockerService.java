package com.digitisation.branchreports.service;

import java.util.List;

import com.digitisation.branchreports.model.Branch;
import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.model.LockerMaster;

public interface LockerService {

	public List<LockerMaster> getalllocker();
	public LockerMaster addlocker(LockerMaster reportmas);

}
