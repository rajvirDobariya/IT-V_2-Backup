package com.digitisation.branchreports.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class EmployeeRole implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long roleId;
	
	private String roleName;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "emp_details_id")
	@JsonIgnoreProperties("employeeDetails")
	private EmployeeDetails employeeDetails;
	
	public EmployeeRole(){}
	
	

	public EmployeeRole(long roleId, String roleName) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
	}



	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public EmployeeDetails getEmployeeDetails() {
		return employeeDetails;
	}

	public void setEmployeeDetails(EmployeeDetails employeeDetails) {
		this.employeeDetails = employeeDetails;
	}
	
	

}
