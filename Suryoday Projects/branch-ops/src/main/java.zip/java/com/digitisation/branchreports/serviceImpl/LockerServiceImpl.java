package com.digitisation.branchreports.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.LockerMaster;
import com.digitisation.branchreports.repository.LockerRepository;
import com.digitisation.branchreports.service.LockerService;

@Service
public class LockerServiceImpl implements LockerService {
	
	@Autowired
	private LockerRepository lockerrepo;

	@Override
	public List<LockerMaster> getalllocker() {
		return lockerrepo.findAll();
	}

	@Override
	public LockerMaster addlocker(LockerMaster lockermas) {
		return lockerrepo.saveAndFlush(lockermas);
	}

	
	

}
