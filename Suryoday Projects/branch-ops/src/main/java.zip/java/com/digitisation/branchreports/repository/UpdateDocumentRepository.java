package com.digitisation.branchreports.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.UpdateDocument;

@Repository
@Transactional
public interface UpdateDocumentRepository extends JpaRepository<UpdateDocument, Long> {

	@Query("SELECT b FROM UpdateDocument b where b.updateAccountId= :updateAccountId ")
	List<UpdateDocument> getDataByAccountId(@Param("updateAccountId")String updateAccountId);
	
//	@Modifying
//	@Query(value="Delete  from update_document k where k.update_account_id =:updateAccountId" ,nativeQuery = true)
//	int removeAccountFromBatch(@Param("updateAccountId")String updateAccountId);
	
	@Modifying
	@Query("Delete from UpdateDocument k where k.updateAccountId =:updateAccountId")
	int removeAccountFromBatch(@Param("updateAccountId")String updateAccountId);
	
	@Modifying
	  @Query("update UpdateDocument k set k.selectColumn= :selectColumn, k.status= :status where k.updateAccountId= :updateAccountId and  k.documentName = :documentName")
	 
	  int updateDocumentsData(@Param("updateAccountId")String updateAccountId,@Param("documentName")String documentName,@Param("selectColumn")boolean selectColumn,@Param("status")String status);

	
	
	
}
	
