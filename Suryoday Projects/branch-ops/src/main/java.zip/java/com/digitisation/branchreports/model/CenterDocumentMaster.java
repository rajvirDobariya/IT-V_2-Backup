package com.digitisation.branchreports.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class CenterDocumentMaster {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long centerDocumentMasterId;
	private String centerDocumentName;
	
	@OneToOne(mappedBy = "centerDocumentMaster")
	private DocumentMaster documentMaster;
	
	public CenterDocumentMaster() {}

	

	public long getCenterDocumentMasterId() {
		return centerDocumentMasterId;
	}



	public void setCenterDocumentMasterId(long centerDocumentMasterId) {
		this.centerDocumentMasterId = centerDocumentMasterId;
	}



	public DocumentMaster getDocumentMaster() {
		return documentMaster;
	}



	public void setDocumentMaster(DocumentMaster documentMaster) {
		this.documentMaster = documentMaster;
	}



	public String getCenterDocumentName() {
		return centerDocumentName;
	}

	public void setCenterDocumentName(String centerDocumentName) {
		this.centerDocumentName = centerDocumentName;
	}
	
	

}
