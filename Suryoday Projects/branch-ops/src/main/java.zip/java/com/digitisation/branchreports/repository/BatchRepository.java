package com.digitisation.branchreports.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.Batch;


@Repository
public interface BatchRepository extends JpaRepository<Batch, Long>{
	
	List<Batch> getBatchByCreatedBy(String createdBy);
	
	@Query("SELECT b FROM Batch b WHERE b.status ='BATCH_CREATED' OR b.status = 'REJECTED' OR b.status ='UNDER_DESCRIPANCY'"+
			"AND b.centerId = :centerId AND b.createdBy = :createdBy")	
	List<Batch> findAllBatchForUser(@Param("centerId")String centerId, @Param("createdBy")String createdBy);
	
	@Query("SELECT b FROM Batch b WHERE b.status ='PENDING_FOR_APPROVAL' OR b.status ='RECTIFIED_PENDING_FOR_APPROVAL' AND b.centerId = :centerId")
	List<Batch> getBatchForApproval(@Param("centerId") String centerId);
	
	@Query("SELECT b FROM Batch b WHERE b.status ='APPROVED' OR b.status ='RECTIFIED_AND_APPROVED'")
	List<Batch> getBatchForProcessing();
	
	@Query("SELECT b FROM Batch b WHERE b.status ='SEND_TO_STORAGE'")
	List<Batch> getBatchForDispatch();
	
	@Query("SELECT b FROM Batch b WHERE b.status ='UNDER_DESCRIPANCY' OR b.status ='RECTIFIED' AND b.centerId = :centerId")
	List<Batch> getBatchForDescrepancy(@Param("centerId") String centerId);
	
	@Query("SELECT b FROM Batch b WHERE b.centerId = :centerId  and b.status in ('Dispached','Send_For_Retrieval')") 
	List<Batch> getBatchForRetrieval(@Param("centerId") String centerId);
	
	@Query("SELECT b FROM Batch b WHERE (b.centerId = :centerId OR b.batchId= :batchId)and b.status in ('Dispached','Send_For_Retrieval')") 
	List<Batch> getBatchForRetrieval1(@Param("centerId") String centerId,@Param("batchId") long batchId);

//	LoanAccounts updateStatus(LoanAccounts loanAccounts); 
	
//	@Query("update LoanAccounts b set b.status= :status where b.dwAccountId= :dwAccountId")
//	LoanAccounts updateStatus(LoanAccounts loanAccounts);

//	List<LoanAccounts> updateStatus(long batchId, String dwAccountId, String status);
	
	 
	
//	List<LoanAccounts> updateStatus(@Param("dwAccountId")String dwAccountId,@Param("status")String status);
	
//	@Query("update LoanAccounts b set b.status= :status where b.dwAccountId= :dwAccountId")
//	LoanAccounts saveAndFlush(LoanAccounts loanAccounts);

	
}
//update jlg_pdd.loan_accounts SET status = "ok" where batch_id = 18310 and dw_account_id = "230A28K01330";


//new
//@Query("SELECT b FROM Batch b where b.batchId= :batch_id and b.centerDocumentId= :center_doc_id ")
//List<Batch> getDataByAccountId(@Param("updateAccountId")String updateAccountId);

//@Modifying
//  @Query("update LoanAccounts k set k.status= :status where k.batch.batchId= :batchId and  k.dwAccountId= :dwAccountId")
// 
//  int updateBatch(@Param("batchId")long batchId,@Param("dwAccountId")String dwAccountId,@Param("status")String status);