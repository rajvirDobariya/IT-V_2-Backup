package com.digitisation.branchreports.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.BranchChecker;
import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.service.BranchCheckerService;
import com.digitisation.branchreports.service.BranchUserMakerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class BranchCheckerController {
	@Autowired
	private BranchCheckerService branchcheckerservice;
	
	
	@PostMapping("/getreportforchecker")
	public List<BranchUserMakerModel> getallreports(BranchUserMakerModel bm) {
	
		
		return branchcheckerservice.getreports(bm);
	}
}
