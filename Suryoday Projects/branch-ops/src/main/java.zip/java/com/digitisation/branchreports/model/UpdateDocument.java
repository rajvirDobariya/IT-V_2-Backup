package com.digitisation.branchreports.model;


import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Type;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
public class UpdateDocument implements Serializable{
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long Id;
	private String updateAccountId;
	private String documentName;
	private String status;
	



	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}



	@Column(columnDefinition = "TINYINT")
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean selectColumn;
	
	
	
//	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name = "loan_doc_id",nullable = false)
//	@JsonIgnoreProperties("loanAccounts")
//	private LoanDocuments loanDocuments;
	
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "loan_doc_id",nullable = false)
//	@JsonIgnoreProperties("updateDocument")
//	private LoanDocuments loanDocuments;
//	
	
//	public LoanDocuments getLoanDocuments() {
//		return loanDocuments;
//	}
//
//
//	public void setLoanDocuments(LoanDocuments loanDocuments) {
//		this.loanDocuments = loanDocuments;
//	}



	public UpdateDocument() {
		super();
	}

	
	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}



	public String getUpdateAccountId() {
		return updateAccountId;
	}



	public void setUpdateAccountId(String updateAccountId) {
		this.updateAccountId = updateAccountId;
	}



	public boolean isSelectColumn() {
		return selectColumn;
	}



	public void setSelectColumn(boolean selectColumn) {
		this.selectColumn = selectColumn;
	}
	


	
}
