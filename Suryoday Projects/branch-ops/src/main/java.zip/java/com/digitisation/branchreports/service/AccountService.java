package com.digitisation.branchreports.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.model.LoanAccountsData;
import com.digitisation.branchreports.model.LoanAccountsData2;
import com.digitisation.branchreports.model.LoanDocuments;

public interface AccountService {
	
	String uploadAccountsFile(MultipartFile[] uploadingFiles);
//	List<LoanAccountsData> uploadAccountsFile(MultipartFile[] uploadingFiles);

	LoanAccountsData getAccountByAcNo(String accountNumber);
	
	public LoanDocuments updateDocument(LoanDocuments loanDocuments);
//	List<LoanAccounts> updateStatus(String dwAccountId, String status);
//	public List<LoanAccounts> updateBatch1(LoanAccounts loanAccounts);
//	List<LoanAccounts> updateBatch1(List<LoanAccounts> loanAccounts);
	LoanAccounts updateBatch1(LoanAccounts loanAccounts);
}
