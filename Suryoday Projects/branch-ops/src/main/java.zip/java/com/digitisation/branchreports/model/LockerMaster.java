package com.digitisation.branchreports.model;

import javax.persistence.*;

@Entity
@Table(name="LockerMaster")
public class LockerMaster {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String branchname;
	private String branchcode;
	public String getBranchcode() {
		return branchcode;
	}
	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}
	private String lockeravailable;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public String getLockeravailable() {
		return lockeravailable;
	}
	public void setLockeravailable(String lockeravailable) {
		this.lockeravailable = lockeravailable;
	}
}
