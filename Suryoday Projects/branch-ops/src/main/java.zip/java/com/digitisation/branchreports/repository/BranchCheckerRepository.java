package com.digitisation.branchreports.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.BranchChecker;
import com.digitisation.branchreports.model.BranchUserMakerModel;


@Repository

public interface BranchCheckerRepository  extends   JpaRepository<BranchChecker,Long>{

	@Query("SELECT b FROM BranchUserMakerModel b where b.status=:status and b.creationdate<=:creationdate and b.reportstatus is NULL")
	List<BranchUserMakerModel> getreportschecker(@Param("status")String status,@Param("creationdate")Date creationdate);
}
