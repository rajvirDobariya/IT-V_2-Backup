package com.digitisation.branchreports.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.*;

@Transactional
@Repository

public interface ReportMasterRepository extends JpaRepository<RepMaster, Long> {

	@Modifying
	@Query("update RepMaster k set k.reportextracted= :reportextracted,k.reportfrequency= :reportfrequency,k.reportapplicable=:reportapplicable where k.reportname= :reportname and k.reportid=:reportid")
	int updatereport(@Param("reportname") String reportname, @Param("reportextracted") String reportextracted,
			@Param("reportfrequency") String reportfrequency, @Param("reportapplicable") String reportapplicable,
			@Param("reportid") long reportid);

//
	@Modifying
	@Query("update BranchUserMakerModel k set k.creationdate= :creationdate,k.lastdate = :lastdate,k.status=:status,k.frequency=:frequency"
			+ " where k.reportname= :reportname")
	int updatereportbranchusermaker(@Param("creationdate") Date creationdate, @Param("lastdate") Date lastdate,
			@Param("status") String status, @Param("frequency") String frequency,
			@Param("reportname") String reportname);

//	  
	@Modifying
	@Query("Delete from RepMaster k where k.reportname =:reportname")
	int removereportbyname(@Param("reportname") String reportname);

	@Query("SELECT b FROM RepMaster b WHERE b.reportname =:reportname")
	RepMaster getreportbyname(@Param("reportname") String reportname);

	@Modifying
	@Query("update RepMaster k set k.deleteflag= :deleteflag where k.reportname= :reportname and k.reportid=:reportid")
    int adddeleteflag(@Param("reportname") String reportname, @Param("deleteflag") int deleteflag,@Param("reportid") long reportid);

	
	@Query("SELECT b FROM RepMaster b WHERE b.deleteflag =:deleteflag")
	List<RepMaster> getallreports(@Param("deleteflag") int deleteflag);
}
