package com.digitisation.branchreports.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.LoanAccountsData2;

@Repository
public interface AccountsRepository2 extends JpaRepository<LoanAccountsData2, Long> {

	public LoanAccountsData2 getLoanAccountsDataByDwAccountId(String dwAccountId);

	@Query("select p from LoanAccountsData2 p where p.dwAccountId= : dwAccountId ")
	public LoanAccountsData2 getLoanAccountsDataByDwAccountIds(String dwAccountId);




}
