package com.digitisation.branchreports.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.model.HolidayMaster;
import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.model.LoanDocuments;

@Repository
@Transactional
public interface BranchUserMakerRepository extends JpaRepository<BranchUserMakerModel, Long>  {

	  @Modifying
	  @Query(value = "INSERT INTO branch_user_maker (reportname,frequency,creationdate,status,lastdate,rep_id)  SELECT * FROM(SELECT ?1 as col1,?2 as col2,?3 as col3,?4 as col4,?5 as col5,?6 as col6) AS tmp WHERE NOT EXISTS (SELECT reportname,frequency,creationdate,lastdate,rep_id FROM branch_user_maker WHERE reportname=?1 and frequency=?2 and creationdate=?3 and lastdate=?5 and rep_id=?6) LIMIT 1 ", nativeQuery = true)
	public int insertingdata(String reportname,String frequency,String creationdate,String status,String lastdate,long repid);
	
	  @Modifying
	  @Query("update BranchUserMakerModel k set k.filename=:filename, k.uploadfile= :uploadfile,k.dataavailable=:dataavailable,k.dataverified=:dataverified,k.status=:status where k.reportname= :reportname and k.lastdate=:creationdate")
	  int updatereport(@Param("uploadfile")byte[] uploadfile,@Param("creationdate") Date creationdate,@Param("reportname") String reportname,@Param("dataavailable") String dataavailable,@Param("dataverified") String dataverified,@Param("status")String status,@Param("filename")String filename);

	  @Modifying
	  @Query("update BranchUserMakerModel k set k.reportstatus=:reportstatus,k.checkercomments=:checkercomments where k.reportname= :reportname  and k.frequency=:frequency and k.lastdate=:lastdate")
	  int acceptcheckstatus(@Param("reportstatus") String reportstatus,@Param("checkercomments") String comments,@Param("reportname") String reportname,@Param("frequency")String frequency,@Param("lastdate")Date lastdate);
	
	  
	  @Modifying
	  @Query("update BranchUserMakerModel k set k.reportstatus=:reportstatus, k.checkercomments= :checkercomments,k.status= :status  where k.reportname= :reportname  and k.frequency=:frequency and k.lastdate=:lastdate")
	  int rejectcheckstatus(@Param("reportstatus") String reportstatus,@Param("checkercomments") String comments,@Param("status") String status,@Param("reportname") String reportname,@Param("frequency")String frequency,@Param("lastdate")Date lastdate);
	
	  
	  @Modifying
	  @Query("update BranchUserMakerModel k set k.status= :status where k.reportname= :reportname and k.frequency=:frequency and k.creationdate=:creationdate and k.lastdate=:lastdate")
	  int updateexception(@Param("status") String status,@Param("reportname") String reportname,@Param("frequency")String frequency,@Param("creationdate")Date creationdate,@Param("lastdate")Date lastdate);

//		@Query("SELECT b FROM BranchUserMakerModel b where b.status= :status and b.creationdate between :dateBeforeDays and  :currentdate")
//		List<BranchUserMakerModel> getreportdata(@Param("status")String status,@Param("dateBeforeDays")Date dateBeforeDays,@Param("currentdate")Date currentdate);
		
//		@Query("SELECT b FROM BranchUserMakerModel b where b.status not in:status and b.frequency IN (:frequency) and b.creationdate<=:creationdate")
//		List<BranchUserMakerModel> showreports(@Param("status")String status,@Param("frequency")List<String> frequency,@Param("creationdate")Date creationdate);
		

		@Query("SELECT b FROM BranchUserMakerModel b where NOT b.status=:status and b.creationdate<=:creationdate and b.repmaster.deleteflag=:deleteflag and   NOT b.repmaster.reportenddate=:todaydate and b.branchname='Belapur'")
		List<BranchUserMakerModel> getreports(@Param("status")String status,@Param("creationdate")Date creationdate,@Param("deleteflag")int deleteflag,@Param("todaydate")Date todaydate );

		@Query("SELECT b FROM BranchUserMakerModel b where  b.reportstatus=:status and b.creationdate  BETWEEN  :creationdate and :lastdate")
		List<BranchUserMakerModel> retrievereportsbydate(@Param("status")String status,@Param("creationdate")Date creationdate,@Param("lastdate")Date lastdate);


		@Query("SELECT b FROM BranchUserMakerModel b where b.status=:status and  b.repmaster.deleteflag=:deleteflag")
		List<BranchUserMakerModel> allexceptionreports(@Param("status")String status,@Param("deleteflag")int deleteflag);

		
		@Query(nativeQuery = true, value ="select case when (count(*) >0) then true else false end from dual where exists(SELECT * FROM holiday_master  where holidaydate=?1)")
		Integer  validatedate(@Param("holidaydate")String holidaydate);

//		@Query("insert into FROM BranchUserMakerModel(status,frequency) b where b.status=:status and b.frequency IN (:frequency)")
//		List<BranchUserMakerModel> insertblankreport(@Param("status")String status,@Param("frequency")List<String> frequency);
//		
		
		
		
		
		
		

	//
}
