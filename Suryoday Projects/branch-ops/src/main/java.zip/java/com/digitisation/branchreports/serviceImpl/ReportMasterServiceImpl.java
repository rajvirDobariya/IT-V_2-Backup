package com.digitisation.branchreports.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.*;
import com.digitisation.branchreports.repository.ReportMasterRepository;
import com.digitisation.branchreports.service.ReportMasterService;

@Service

public class ReportMasterServiceImpl implements ReportMasterService {

	@Autowired
	private ReportMasterRepository reportres;

	@Override
	public List<RepMaster> getalldata() {
		return reportres.getallreports(1);
	}

	@Override
	public int updatereport(BranchUserMakerModel bkm) {
		reportres.updatereportbranchusermaker(bkm.getCreationdate(),bkm.getLastdate(), bkm.getStatus(), bkm.getFrequency(), bkm.getReportname());
		return reportres.updatereport(bkm.getRepmaster().getReportname(),bkm.getRepmaster().getReportextracted(),bkm.getRepmaster().getReportfrequency(),bkm.getRepmaster().getReportapplicable(),bkm.getRepmaster().getReportid());
	}

	@Override
	public int deletereportbyname(RepMaster rm) {
		return reportres.adddeleteflag(rm.getReportname(),0,rm.getReportid());
	}

	@Override
	public RepMaster getreportbyname(String reportname) {
		return reportres.getreportbyname(reportname);
	}

}
