package com.digitisation.branchreports.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
public class BranchMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long branchid;
	private String applicablefor;
	private String branchcode;
	private String city;
	private String pincode;

	
	@OneToOne(mappedBy = "branchmaster",fetch = FetchType.LAZY)
	@JsonIgnoreProperties("branchmaster")
	private RepMaster repmaster;
	
//	@ManyToOne(targetEntity = BranchMaster.class)
//	@JsonIgnoreProperties("branchmaster")
//	private RepMaster repmaster;
//
//
//
	public RepMaster getRepmaster() {
		return repmaster;
	}

	public void setRepmaster(RepMaster repmaster) {
		this.repmaster = repmaster;
	}



	

	public String getApplicablefor() {
		return applicablefor;
	}
	public void setApplicablefor(String applicablefor) {
		this.applicablefor = applicablefor;
	}
	public long getBranchid() {
		return branchid;
	}
	public void setBranchid(long branchid) {
		this.branchid = branchid;
	}
	public String getBranchcode() {
		return branchcode;
	}

	public void setBranchcode(String branchcode) {
		this.branchcode = branchcode;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}




}
