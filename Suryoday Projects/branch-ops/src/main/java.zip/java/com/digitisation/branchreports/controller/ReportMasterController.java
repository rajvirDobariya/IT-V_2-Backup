package com.digitisation.branchreports.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.model.RepMaster;
import com.digitisation.branchreports.model.SuccessPojo;
import com.digitisation.branchreports.service.BranchUserMakerService;
import com.digitisation.branchreports.service.ReportMasterService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class ReportMasterController {
	
	@Autowired
	private BranchUserMakerService branchuserservice;
	
	@Autowired
	private ReportMasterService respservice;
	
	private SuccessPojo successPojo=null;;
	
	@PostMapping("/getAllReports")
	public List<RepMaster> getallreports() {

		System.out.println("Get All Data : "+respservice.getalldata().size());
		
		return respservice.getalldata();
	}
	
	@PostMapping("/updateReports")
	
	public SuccessPojo  updatereport(@RequestBody BranchUserMakerModel reportmas) {

		int i = respservice.updatereport(reportmas);
		System.out.println(" i : "+ i );
		if (i > 0) {
		successPojo=new SuccessPojo(200, "Updated Sucessfully");
		    return successPojo;

		} else {
			
			successPojo=new SuccessPojo(500, "Not Updated Sucessfully");

		    return successPojo;			
		}
	
	}
	
	
	@PostMapping("/addreport")
	public BranchUserMakerModel addreport(@RequestBody BranchUserMakerModel bkm) {

 		return branchuserservice.addreport(bkm);
	}
	
	
	@PostMapping("/deletereportbyname")
	public int deletereport(@RequestBody RepMaster reportmas) {
		System.out.println("Report mas :: "+reportmas.getReportname());

		return respservice.deletereportbyname(reportmas);
	}

	@PostMapping("/getreportdatabyname")
	public RepMaster getreportdatabyname(@PathParam("reportname") String reportname) {
	
		return respservice.getreportbyname(reportname);
	}
	
	

	

}
