package com.digitisation.branchreports.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.model.SuccessPojo;
import com.digitisation.branchreports.repository.BranchUserMakerRepository;
import com.digitisation.branchreports.service.BranchUserMakerService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class BranchUserMakerController {
	@Autowired
	private BranchUserMakerService branchuserservice;

	@Autowired
	private BranchUserMakerRepository branchuserrepo;
	
	private SuccessPojo successPojo=null;;


	@PostMapping("/branchusertest")
	public SuccessPojo addreport(@RequestParam("reportname") String reportname,
			@RequestParam("uploadfile") MultipartFile uploadFile, @RequestParam("branchname") String branchname,
			@RequestParam("currentdate") Date currentdate, @RequestParam("dataavailable") String dataavailable,
			@RequestParam("dataverified") String dataverified, @RequestParam("filename") String filename,
			@RequestParam("status") String status) {
     int i = branchuserservice.storeFile(reportname, status, "", currentdate, uploadFile, dataavailable, dataverified,
				filename);
		if (i > 0) {
			successPojo = new SuccessPojo(200, "Updated Sucessfully");
			return successPojo;
		} else {
			successPojo = new SuccessPojo(500, "Not Updated Sucessfully");
			return successPojo;
		}
	}

	@PostMapping("/getreportformaker")
	public List<BranchUserMakerModel> getallreports(BranchUserMakerModel bm) {
		return branchuserservice.getreports(bm);
	}

	@PostMapping("/updatecheckstatus")
	public int updatechecker(@RequestBody BranchUserMakerModel bm) {
		return branchuserservice.updatechecker(bm);
	}

	@PostMapping("/insertblankdata")
	public int insertdata(@RequestBody BranchUserMakerModel bm) {
		return branchuserservice.updatechecker(bm);
	}

	@PostMapping("/retrievereports")
	public List<BranchUserMakerModel> retrievereports(@RequestParam("status") String status,
			@RequestParam("lastdate") Date lastdate,@RequestParam("startdate") Date startdate) {

		return branchuserrepo.retrievereportsbydate(status,startdate,lastdate);
	}

	@PostMapping("/exceptionreportlist")
	public List<BranchUserMakerModel> exceptionreports(@RequestParam("status") String status) {
		return branchuserservice.allexceptionreport(status);
	}
	
//	@Scheduled(cron = "0 0 0 * * *",zone = "Indian/Maldives")
//	public void cronJobSch() {
//		Calendar cal = Calendar.getInstance();
//		boolean sunday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
//		Integer val=branchuserrepo.validatedate("2020-02-18");
//		if (val == 0 && !sunday) {
//
//			branchuserimpl.insertdata();
//
//		}
//	}

}
