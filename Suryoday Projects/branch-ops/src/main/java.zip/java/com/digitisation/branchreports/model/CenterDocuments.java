package com.digitisation.branchreports.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.springframework.boot.autoconfigure.reactor.core.ReactorCoreProperties;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class CenterDocuments implements Serializable{
	
	/**
	 * Center Documents 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long centerDocumentId;

	private boolean cgt;
	private boolean grt;
	private boolean centerMap;
	private boolean chargeReceipt;
	private boolean desbReceipt;
	
	@OneToOne(mappedBy = "centerDocuments")
	private Batch batch;


	@OneToOne(mappedBy = "centerDocuments")
	private Address address;
	
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public CenterDocuments() {}

	public long getCenterDocumentId() {
		return centerDocumentId;
	}

	public void setCenterDocumentId(long centerDocumentId) {
		this.centerDocumentId = centerDocumentId;
	}

	public boolean isCgt() {
		return cgt;
	}

	public void setCgt(boolean cgt) {
		this.cgt = cgt;
	}

	public boolean isGrt() {
		return grt;
	}

	public void setGrt(boolean grt) {
		this.grt = grt;
	}

	public boolean isCenterMap() {
		return centerMap;
	}

	public void setCenterMap(boolean centerMap) {
		this.centerMap = centerMap;
	}

	public boolean isChargeReceipt() {
		return chargeReceipt;
	}

	public void setChargeReceipt(boolean chargeReceipt) {
		this.chargeReceipt = chargeReceipt;
	}

	public boolean isDesbReceipt() {
		return desbReceipt;
	}

	public void setDesbReceipt(boolean desbReceipt) {
		this.desbReceipt = desbReceipt;
	}

	public Batch getBatch() {
		return batch;
	}

	public void setBatch(Batch batch) {
		this.batch = batch;
	}

	
}
