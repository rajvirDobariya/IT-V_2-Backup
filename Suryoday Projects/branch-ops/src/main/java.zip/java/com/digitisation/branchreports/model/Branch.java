package com.digitisation.branchreports.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
public class Branch implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
	private long id;

	private String branchCode;
	private String address;
	private String branchName;

	private String boType;
	private String branchOperationDate;
	private String country;
	private String linkedBranch;
	private String ouType;
	private String stateName;
	private String zoneName;

	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getBoType() {
		return boType;
	}

	public void setBoType(String boType) {
		this.boType = boType;
	}

	public String getBranchOperationDate() {
		return branchOperationDate;
	}

	public void setBranchOperationDate(String branchOperationDate) {
		this.branchOperationDate = branchOperationDate;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLinkedBranch() {
		return linkedBranch;
	}

	public void setLinkedBranch(String linkedBranch) {
		this.linkedBranch = linkedBranch;
	}

	public String getOuType() {
		return ouType;
	}

	public void setOuType(String ouType) {
		this.ouType = ouType;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getZoneName() {
		return zoneName;
	}

	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}

	public Branch() {}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	

}
