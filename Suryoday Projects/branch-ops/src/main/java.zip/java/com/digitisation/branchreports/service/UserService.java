package com.digitisation.branchreports.service;

import java.util.List;

import com.digitisation.branchreports.model.EmployeeDetails;
import com.digitisation.branchreports.model.EmployeeRole;

public interface UserService {

	public EmployeeDetails saveEmployeeDetails(EmployeeDetails emp);
	public EmployeeDetails getEmployeeByEmpCode(String empCode);
	public List<EmployeeDetails> getAllEmployee();
	EmployeeRole saveEmployeeRole(EmployeeRole empRole);
}
