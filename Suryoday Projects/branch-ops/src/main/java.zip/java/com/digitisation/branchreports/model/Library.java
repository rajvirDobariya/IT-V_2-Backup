package com.digitisation.branchreports.model;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;



@Entity
public class Library {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private long id;
	private String bookname;
	

    public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getBookname() {
		return bookname;
	}


	public void setBookname(String bookname) {
		this.bookname = bookname;
	}



	
	
}
