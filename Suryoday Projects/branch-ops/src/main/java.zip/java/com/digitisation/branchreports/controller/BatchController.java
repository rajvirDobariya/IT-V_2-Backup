package com.digitisation.branchreports.controller;

import java.util.List;
import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.CenterDocumentMaster;
import com.digitisation.branchreports.model.CenterDocuments;
import com.digitisation.branchreports.model.DocumentMaster;
import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.repository.AccountsRepository;
import com.digitisation.branchreports.repository.BatchRepository;
import com.digitisation.branchreports.repository.CenterDocumentDataRepository;
import com.digitisation.branchreports.repository.CenterDocumentRepository;
import com.digitisation.branchreports.repository.LoanAccountsRepository;
import com.digitisation.branchreports.service.AccountService;
import com.digitisation.branchreports.service.BatchService;
import com.digitisation.branchreports.service.CenterDocumentService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BatchController {
	
	@Autowired
	private CenterDocumentService centerDocumentService;
	
	@Autowired
	private BatchService batchService;
	@Autowired
	private AccountService accountService;
	@Autowired
	public void setBatchService(BatchService batchService) {
		this.batchService = batchService;
	}
	
	@Autowired
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	
	
	@Autowired
	private BatchRepository batchRepository;
	
	@Autowired
	private LoanAccountsRepository loanAccountRepository ;

	

	@Autowired
	private CenterDocumentDataRepository centerDocumentDataRepository;
	

	@PostMapping("/getBatchById")
	public ResponseEntity<Optional<Batch>> getBatchById(@RequestBody String id){
		Long batchId = Long.parseLong(id);
		return new ResponseEntity<>(batchService.getBatchById(batchId),HttpStatus.OK);
	}
	
	@PostMapping("/createBatch")
	public ResponseEntity<Batch> createBatch(@RequestBody Batch batch) {
		if(batch != null) {
			batchService.createBatch(batch);
		}
		else {
			return new ResponseEntity<Batch>(new Batch(),HttpStatus.NOT_ACCEPTABLE);
		}
		return new ResponseEntity<Batch>(batchService.createBatch(batch),HttpStatus.CREATED);
	}
	
	@PostMapping("/updateBatch")
	public Batch updateBatch(@RequestBody Batch batch) {
		long batchId = batch.getBatchId();
		LoanAccounts loanAccounts = null;
		for(int i=0; i<=batch.getLoanAccounts().size()-1;i++) {
		 loanAccounts = batch.getLoanAccounts().get(i);
		 accountService.updateBatch1(loanAccounts);
		}
	
	
		return batchService.updateBatch(batch);
	}
	
	@PostMapping("/getAllBatches")
	public List<Batch> getAllBatches(@PathParam("centerId") String centerId,
			@PathParam("createdBy") String createdBy){
		return batchService.getAllBatches(centerId,createdBy);
	}
	
	@PostMapping("/getBatchForDispatch")
	public List<Batch> getBatchPendingForApproval(){
		return batchService.getBatchForDispath();
	}
	
	@PostMapping("/getBatchForProcessing")
	public List<Batch> getBatchForProcessing(@PathParam("status") String status){
		System.out.println(status);
		return batchService.getBatchForProcessing();
	}
	
	@PostMapping("/getBatchForUser")
	public List<Batch> getBatchForApproval(@PathParam("centerId") String centerId,
			@PathParam("createdBy") String createdBy){
		return batchRepository.findAllBatchForUser(centerId,createdBy);
	}
	
	@PostMapping("/getBatchForApporval")
	public List<Batch> getBatchForApproval(@PathParam("centerId") String centerId){
		return batchService.getBatchForApproval(centerId);
	}
	
	@PostMapping("/getBatchForDescrepancy")
	public List<Batch> getBatchesForDescrepancy(@PathParam("centerId") String centerId){
		return batchService.getBatchForDescrepancy(centerId);
	}
	
	
	
	@PostMapping("/getCenterDocumentById")
   public Optional<CenterDocuments> getCenterDocumentById(@RequestBody CenterDocuments centerDocuments) {
		
	
		return centerDocumentService.getCenterDocumentById(centerDocuments);

 }
	
	@PostMapping("/getBatchForRetrieval")
	public List<Batch> getBatchForRetrieval(@PathParam("centerId") String centerId){
		return batchService.getBatchForRetrieval(centerId );
	}
	
	@PostMapping("/getBatchForRetrievalOne")

	public List<Batch> getBatchForRetrieval1(@PathParam("centerId") String centerId,@PathParam("batchId") long batchId,@PathParam("dwAccountId") String dwAccountId){
		if(!"null".equals(dwAccountId)) {
		List<LoanAccounts> LoanAccountDetails = (List<LoanAccounts>) loanAccountRepository.getBatchByAcId(dwAccountId);
		System.out.println("**************************"+LoanAccountDetails);
		if(LoanAccountDetails.size() == 0) {
			batchId = 00000;
		}
		else {
		batchId = LoanAccountDetails.get(0).getBatch().getBatchId();
		System.out.println("**************************"+batchId);
		}
		}
		return batchService.getBatchForRetrieval1(centerId , batchId);
	}
	
	
	
	
//	@PostMapping("/updateStatus")
//	public List <LoanAccounts> updateStatus(@RequestBody Batch batch) {
//		long batchId = batch.getBatchId();
//		String dwAccountId = batch.getLoanAccounts().get(0).getDwAccountId();
//		String status = batch.getLoanAccounts().get(0).getStatus();
//		System.out.println("acc id*****"+ batch.getLoanAccounts().get(0).getDwAccountId());
//		System.out.println("status *****"+batch.getLoanAccounts().get(0).getStatus());
//		return accountService.updateStatus(dwAccountId, status);
//		
//	}



}



//
//batch.getLoanAccounts().get(0).getStatus();
//System.out.println("loan account status **********"+batch.getLoanAccounts().get(0).getStatus());



