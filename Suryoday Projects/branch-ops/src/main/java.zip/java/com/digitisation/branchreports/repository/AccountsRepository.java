package com.digitisation.branchreports.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.model.LoanAccountsData;
import com.digitisation.branchreports.model.LoanDocuments;

@Repository
public interface AccountsRepository extends JpaRepository<LoanAccountsData, Long> {

	public LoanAccountsData getLoanAccountsDataByDwAccountId(String accountNo);

	public LoanDocuments saveAndFlush(LoanDocuments loanDocuments);

//	public LoanAccounts saveAndFlush(LoanAccounts loanAccounts);

//	public LoanDocuments saveAndFlush(LoanDocuments loanDocuments);

//	public LoanAccounts updateStatus(LoanAccounts loanAccounts);

}
