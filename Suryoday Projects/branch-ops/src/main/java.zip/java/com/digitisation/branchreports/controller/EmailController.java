package com.digitisation.branchreports.controller;

	import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import javax.mail.MessagingException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.mail.MailException;
	import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.Email;
import com.digitisation.branchreports.service.EmailService;

	
	@RestController
	public class EmailController {
		
//		@Autowired
//		private EmailService emailService;
//		
//		@Autowired
//		private Email email;
//		
//		@RequestMapping("send-mail")
//		public String send() {
//
//			
//			email.setEmailId("anuragsn94@gmail.com");  //Receiver's email address
//			
//			try {
//				emailService.sendEmail(email);
//			} catch (MailException mailException) {
//				System.out.println(mailException);
//			}
//			return "Congratulations! Your mail has been send to the user.";
//		}
//		
////		@RequestMapping("send-mail-attachment")
////		public String sendWithAttachment() throws MessagingException {
////
////			/*
////			 * Creating a User with the help of User class that we have declared and setting
////			 * Email address of the sender.
////			 */
////			email.setEmailId(""); //Receiver's email address
////
////			/*
////			 * Here we will call sendEmailWithAttachment() for Sending mail to the sender
////			 * that contains a attachment.
////			 */
////			try {
////				emailService.sendEmailWithAttachment(email);
////			} catch (MailException mailException) {
////				System.out.println(mailException);
////			}
////			return "Congratulations! Your mail has been send to the user.";
////		}
//		
//		// Excel upload functionality
//		@RequestMapping(value = "/updateBulkRecord", method = RequestMethod.POST)
//		public SuccessBean updateBulkRecord (@RequestParam("uploadingFiles") MultipartFile[] uploadingFiles,
//				 @RequestParam String uploadedBy, @RequestParam String recordTypeId,
//				 @RequestParam String roleId, @RequestParam String loggedInUserBranchCode){
//			 SuccessBean successBean = new SuccessBean();
//			 
//			 int noOfCount = 0;
//			 Map<String, String> awbMap = new HashMap<>();
//			 String outerCourierName = "";
//			 String outerDispatchDate = "";
//			 String branchNameForEmailSending = "";
//			 
//			 InventoryController inventoryController = new InventoryController();
//			 Map<String, DLMSBranchMaster> dlmsBranchMaster = inventoryController.fillBranchMaster();
//			 
//			 
//			 if(recordTypeId.equals("1") || recordTypeId.equals("2")) {
//				 String sql = "update tbl_branch_documents_records set  "
//					 		+ "AWB_no = ?, courier_name = ?, dispatch_date = ?, status = '"+BranchEnum.SENT_TO_CPU.value()+"', "
//					 		+ " dispatch_by = ?, last_updated_by = '"+uploadedBy+"', last_updated_on = now() where date(report_date) = ?"
//					 		+ " and record_type_id = "+recordTypeId+" and branch_code = ? and status = '"+BranchEnum.UPLOADED.value()+"' ";
//				 for (MultipartFile multipartFile : uploadingFiles) {
//					 if(recordTypeId.equals("1")) {
//						 if(!multipartFile.getOriginalFilename().toUpperCase().startsWith("REPORTS")) {
//							 successBean.setStatus("500");
//							 successBean.setStatusMessge("Record Type and file name is mismatched. File Name should starts with keyword Report");
//							 return successBean;
//						 }
//					 }else {
//						 if(!multipartFile.getOriginalFilename().toUpperCase().startsWith("VOUCHER")) {
//							 successBean.setStatus("500");
//							 successBean.setStatusMessge("Record Type and file name is mismatched. File Name should starts with keyword Voucher");
//							 return successBean;
//						 }
//					 }
//					 Workbook wb = null;
//					 
//					 try{
//						 wb = WorkbookFactory.create(multipartFile.getInputStream());
//					 }catch(Exception e) {
//						 e.printStackTrace();
//						 LOGGER.error("Exception : ", e);
//						 successBean.setStatus("500");
//						 successBean.setStatusMessge("Invalid file format. supported file format is .xls and .xlsx");
//						 return successBean;
//					 }
//					 
//					 try(Connection connection = ConnectionUtil.getConnection();
//							 PreparedStatement pstmt = connection.prepareStatement(sql)) {
//						Sheet sheet = wb.getSheetAt(0);
//						Cell cell;
//						
//						String acOpenDate = "";
//						String awbNo = "";
//						String courierName = "";
//						String dispatchDate = "";
//						String branchCode = "";
//						String branchName = "";
//						String noOfBook = "";
//						int updateCount;
//						int lineNo = 1;
//						SimpleDateFormat sm = new SimpleDateFormat("MM-dd-yyyy");
//						for(int i = 0 ; i <= sheet.getLastRowNum() ; i ++)
//						{
//							System.out.println("i = " + i);
//							if(i == 0){
//								continue;
//							}
//							
//							Row row = sheet.getRow(i);
//							
//							if(row == null){
//								continue;
//							}
//							
//							
//							////////////////////////////////////////////////////
//							try {
//								cell = row.getCell(0);
//								if (cell == null) {
//									continue;
//								}
//			
//								if (cell.getCellType() == 0) {
//									acOpenDate = sm.format(cell.getDateCellValue());
//								} else {
//									acOpenDate = cell.getStringCellValue();
//								}
//			
//								System.out.println("Account open date : " + acOpenDate);
//								if (acOpenDate != null && acOpenDate != "") {
//									pstmt.setDate(5, new Date(DateUtil.getDateObject(acOpenDate, "dd-MM-yyyy").getTime())); // uplaodStr[6]
//								}else {
//									continue;
//								}
//							}catch(Exception e) {
//								LOGGER.error("Exception ", e);
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 0st column and line no : " + lineNo);
//								return successBean;
//							}
//												
//							/////////////////////////////////////////////////////////
//							
//							try {
//								cell = row.getCell(1);
//								if (cell == null) {
//									continue;
//								}
//								if (cell.getCellType() == 1) {
//									noOfBook = cell.getStringCellValue();
//								} else if (cell.getCellType() == 0) {
//									Long noOfBookInt = (long) cell.getNumericCellValue();
//									noOfBook = noOfBookInt + "";
//								}
//							}catch(Exception e) {
//								LOGGER.error("Exception ", e);
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 1st column and line no : " + lineNo);
//								return successBean;
//							}
//							
//							////////////////////////////////////////////////////
//
//							try {
//								cell = row.getCell(2);
//								if (cell == null) {
//									continue;
//								}
//								if (cell.getCellType() == 1) {
//									branchCode = cell.getStringCellValue();
//								} else if (cell.getCellType() == 0) {
//									Long branchCodeInt = (long) cell.getNumericCellValue();
//									branchCode = branchCodeInt + "";
//								}
//								if(dlmsBranchMaster.get(branchCode)!= null) {
//									branchNameForEmailSending = dlmsBranchMaster.get(branchCode).getBranchName();
//								}else {
//									branchNameForEmailSending = branchCode;
//								}
//								pstmt.setString(6, branchCode);
//							}catch(Exception e) {
//								LOGGER.error("Exception ", e);
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 2nd column and line no : " + lineNo);
//								return successBean;
//							}
//							
//							if(roleId.equals("3")) {
//								if(!loggedInUserBranchCode.equals(branchCode)) {
//									continue;
//								}
//							}
//							
//							////////////////////////////////////////////////////
//							
//							try {
//								cell = row.getCell(3);
//								if (cell == null) {
//									continue;
//								}
//								branchName = cell.getStringCellValue();
//								pstmt.setString(2, branchName);
//							}catch(Exception e) {
//								LOGGER.error("Exception ", e);
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 3rd column and line no : " + lineNo);
//								return successBean;
//							}
//							
//						//////////////////////////////////////////////////////
//							try {
//								cell = row.getCell(4);
//								if (cell == null) {
//									continue;
//								}
//								if (cell.getCellType() == 1) {
//									awbNo = cell.getStringCellValue();
//								} else if (cell.getCellType() == 0) {
//									Long awbNoInt = (long) cell.getNumericCellValue();
//									awbNo = awbNoInt + "";
//								}
//								pstmt.setString(1, awbNo);
//							}catch(Exception e) {
//								LOGGER.error("Exception ", e);
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 4th column and line no : " + lineNo);
//								return successBean;
//							}
//												
//						//////////////////////////////////////////////////////
//
//							try {
//								cell = row.getCell(5);
//								if (cell == null) {
//									continue;
//								}
//								courierName = cell.getStringCellValue();
//								outerCourierName = courierName;
//								pstmt.setString(2, courierName);
//							}catch(Exception e) {
//								LOGGER.error("Exception ", e);
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 5th column and line no : " + lineNo);
//								return successBean;
//							}
//		
//							//////////////////////////////////////////////////////
//							
//							try {
//								cell = row.getCell(6);
//								if (cell == null) {
//									continue;
//								}
//			
//								if (cell.getCellType() == 0) {
//									dispatchDate = sm.format(cell.getDateCellValue());
//								} else {
//									dispatchDate = cell.getStringCellValue();
//								}
//			
//								if (dispatchDate != null && dispatchDate != "") {
//									pstmt.setDate(3, new Date(DateUtil.getDateObject(dispatchDate, "MM-dd-yyyy").getTime())); // uplaodStr[6]
//									outerDispatchDate = DateUtil.getStringFormattedDate(new Date(DateUtil.getDateObject(dispatchDate, "MM-dd-yyyy").getTime()), "dd-MM-yyyy");
//								} else {
//									pstmt.setDate(3, null);
//								}
//							}catch(Exception e) {
//								LOGGER.error("Exception ", e);
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 6th column and line no : " + lineNo);
//								return successBean;
//							}
//							
//							pstmt.setString(4, uploadedBy);
//							
//							pstmt.addBatch();
//							updateCount = pstmt.executeUpdate();
//							lineNo++;
//							if(updateCount > 0) {
//								System.out.println("Update COunt : " + updateCount);
//								noOfCount++;
//								awbMap.put(awbNo, "");
//							}
//						}
////						pstmt.executeBatch();
//						successBean.setStatus("200");
//						successBean.setStatusMessge("Request Inserted successfully");
//					} catch (SQLException e) {
//						LOGGER.error("Exception : " , e);
//						successBean.setStatus("400");
//						successBean.setStatusMessge("Request not processed successfully, Database exception ");
//					} catch (EncryptedDocumentException  e1) {
//						e1.printStackTrace();
//						successBean.setStatus("400");
//						successBean.setStatusMessge("Request not processed successfully, column contains invalid format ");
//					} catch (Exception e1) {
//						e1.printStackTrace();
//						successBean.setStatus("400");
//						successBean.setStatusMessge("Request not processed successfully.");
//					}finally {
//						try {
//							wb.close();
//						} catch (IOException e) {
//							e.printStackTrace();
//							LOGGER.error("Exception" , e);
//							
//						}
//					}
//				 }
//			 
//				 
//			 }else if (recordTypeId.equals("3") || recordTypeId.equals("4")) {
//				 String sql = "update tbl_branch_documents_records set  "
//					 		+ "AWB_no = ?, courier_name = ?, dispatch_date = ?, status = '"+BranchEnum.SENT_TO_CPU.value()+"', "
//					 		+ " dispatch_by = ?, last_updated_by = '"+uploadedBy+"', last_updated_on = now()  where ac_no = ? and record_type_id = "+recordTypeId+" and status = '"+BranchEnum.UPLOADED.value()+"'";
//				
//				 for (MultipartFile multipartFile : uploadingFiles) {
//					 
//					 if(recordTypeId.equals("3")) {
//						 if(!multipartFile.getOriginalFilename().toUpperCase().startsWith("SR")) {
//							 successBean.setStatus("500");
//							 successBean.setStatusMessge("Record Type and file name is mismatched. File Name should starts with keyword SR");
//							 return successBean;
//						 }
//					 }else {
//						 if(!multipartFile.getOriginalFilename().toUpperCase().startsWith("ACCOUNT_OPENING_FORM")) {
//							 successBean.setStatus("500");
//							 successBean.setStatusMessge("Record Type and file name is mismatched. File Name should starts with keyword Account_opening_form");
//							 return successBean;
//						 }
//					 }
//					 
//					 Workbook wb = null;
//					 
//					 try{
//						 wb = WorkbookFactory.create(multipartFile.getInputStream());
//					 }catch(Exception e) {
//						 e.printStackTrace();
//						 LOGGER.error("Exception : ", e);
//						 successBean.setStatus("500");
//						 successBean.setStatusMessge("Invalid file format. supported file format is .xls and .xlsx");
//						 return successBean;
//					 }
//					 
//					 try(Connection connection = ConnectionUtil.getConnection();
//							 PreparedStatement pstmt = connection.prepareStatement(sql)) {
//						Sheet sheet = wb.getSheetAt(0);
//						Cell cell;
//						
//						String acNo = "", courierName = "",  awbNo = "", dispatchDate = "", branchCode = "";
//						int updateCount = 0;
//						int lineNo = 0;
//						SimpleDateFormat sm = new SimpleDateFormat("MM-dd-yyyy");
//						for(int i = 0 ; i <= sheet.getLastRowNum() ; i ++)
//						{
//							if(i == 0){
//								continue;
//							}
//							
//							Row row = sheet.getRow(i);
//							
//							if(row == null){
//								continue;
//							}
//									
//						//////////////////////////////////////////////////////
//							
//							try {
//								cell = row.getCell(2);
//								if (cell == null) {
//									continue;
//								}
//								if (cell.getCellType() == 1) {
//									branchCode = cell.getStringCellValue();
//								} else if (cell.getCellType() == 0) {
//									Long branchCodeInt = (long) cell.getNumericCellValue();
//									branchCode = branchCodeInt + "";
//								}
//								
//								if(dlmsBranchMaster.get(branchCode)!= null) {
//									branchNameForEmailSending = dlmsBranchMaster.get(branchCode).getBranchName();
//								}else {
//									branchNameForEmailSending = branchCode;
//								}
//							}catch(Exception e) {
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for colume 2nd column and line no : " + lineNo);
//								return successBean;
//							}
//							if(roleId.equals("3")) {
//								if(!loggedInUserBranchCode.equals(branchCode)) {
//									continue;
//								}
//							}
//							
//
//							//////////////////////////////////////////////////////
//							
//							try {
//								cell = row.getCell(9);
//								if (cell == null) {
//									continue;
//								}
//								if (cell.getCellType() == 1) {
//									awbNo = cell.getStringCellValue();
//								} else if (cell.getCellType() == 0) {
//									Long awbNoInt = (long) cell.getNumericCellValue();
//									awbNo = awbNoInt + "";
//								}
//								pstmt.setString(1, awbNo);
//							}catch(Exception e) {
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 9th column and line no : " + lineNo);
//								return successBean;
//							}
//							
//							//////////////////////////////////////////////////////
//
//							try {
//								cell = row.getCell(10);
//								if (cell == null) {
//									continue;
//								}
//								courierName = cell.getStringCellValue();
//								outerCourierName = courierName;
//								pstmt.setString(2, courierName);							
//							}catch(Exception e) {
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for colume 2nd column and line no : " + lineNo);
//								return successBean;
//							}
//		
//							//////////////////////////////////////////////////////
//
//							try {
//								cell = row.getCell(11);
//								if (cell == null) {
//									continue;
//								}
//			
//								if (cell.getCellType() == 0) {
//									dispatchDate = sm.format(cell.getDateCellValue());
//								} else {
//									dispatchDate = cell.getStringCellValue();
//								}
//			
//								if (dispatchDate != null && dispatchDate != "") {
//									pstmt.setDate(3, new Date(DateUtil.getDateObject(dispatchDate, "MM-dd-yyyy").getTime())); // uplaodStr[6]
//									outerDispatchDate = DateUtil.getStringFormattedDate(new Date(DateUtil.getDateObject(dispatchDate, "MM-dd-yyyy").getTime()), "dd-MM-yyyy");
//								} else {
//									pstmt.setDate(3, null);
//								}
//							}catch(Exception e) {
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for colume 11th column and line no : " + lineNo);
//								return successBean;
//							}
//								
//							pstmt.setString(4, uploadedBy);
//
//							//////////////////////////////////////////////////////
//							
//							try {
//								cell = row.getCell(0);
//								if (cell == null) {
//									continue;
//								}
//								if (cell.getCellType() == 1) {
//									acNo = cell.getStringCellValue();
//								} else if (cell.getCellType() == 0) {
//									Long acNoInt = (long) cell.getNumericCellValue();
//									acNo = acNoInt + "";
//								}
//								pstmt.setString(5, acNo);	
//							}catch(Exception e) {
//								successBean.setStatus("400");
//								successBean.setStatusMessge("Data issue for 0th column and line no : " + lineNo);
//								return successBean;
//							}
//							
////							pstmt.addBatch();
//							updateCount = pstmt.executeUpdate();
//							if(updateCount > 0) {
//								System.out.println("Update COunt : " + updateCount);
//								noOfCount++;
//								awbMap.put(awbNo, "");
//							}
//						}
////						pstmt.executeBatch();
//						successBean.setStatus("200");
//						successBean.setStatusMessge("Request Inserted successfully");
//					}catch (SQLException e) {
////						LOGGER.error("Exception : " , e);
//						successBean.setStatus("400");
//						successBean.setStatusMessge("Request not processed successfully, Database exception ");
//					} catch (EncryptedDocumentException  e1) {
//						e1.printStackTrace();
//						successBean.setStatus("400");
//						successBean.setStatusMessge("Request not processed successfully, Invalid file Format  ");
//					} catch (Exception e1) {
//						e1.printStackTrace();
//						successBean.setStatus("400");
//						successBean.setStatusMessge("Request not processed successfully Invalid file Format");
//					}finally {
//						try {
//							wb.close();
//						} catch (IOException e) {
//							e.printStackTrace();
////							LOGGER.error("Exception" , e);
//						}
//					}
//				 }
//			 }
//			 
//			 if(successBean.getStatus().equals("200")) {
//				 if(awbMap.size() > 0) {
//					 sendMailToCPUUser(awbMap, noOfCount, outerCourierName, outerDispatchDate, recordTypeId, branchNameForEmailSending);
//				 }
//			 }
//			
//			 return successBean;
//		 }
//
//		
//		private int sendMailToCPUUser(Map<String, String> awbMap, int noOfCount, String courierName, String dispatchDate, 
//				String recordTypeId, String branchName) {
//			GeneralUtility generalUtility = new GeneralUtility();
//			String emailIds = generalUtility.getEmailIdsOfGivenPermission(PermissionEnum.RECORD_MGM_MODULE_CPU_USER.value());
//			
//			// Send mail
//			String completeMessage = "";
//			String emailSub = "Form retrival";
//			String bodyHeader= "";
//			String bodyFooter= "";
//				
//			 emailSub = "Record Details Updated";
//			
//			 String awbString = "";
//			 for (String key : awbMap.keySet()) {
//				 if(awbString.equals("")) {
//					 awbString = key;
//				 }else {
//					 awbString = awbString + "," + key;
//				 }
//			 }
//			 
//			 if(recordTypeId.equals("4")) { // AOF
//				 bodyHeader="<table><tr><td>Dear Sir / Madam, </td></tr><tr><td>This is to inform you, "+branchName+" sent "+noOfCount+" (forms) through "+courierName+""
//						 + " courier under AWB number "+awbString+" on "+dispatchDate+", please acknowledge and confirm the receipt</td></tr></table>";
//			 }else if(recordTypeId.equals("3")) { // SR
//				 bodyHeader="<table><tr><td>Dear Sir / Madam, </td></tr><tr><td>This is to inform you, "+branchName+" sent "+noOfCount+" (SR) through "+courierName+""
//						 + " courier under AWB number "+awbString+" on "+dispatchDate+", please acknowledge and confirm the receipt</td></tr></table>";
//			 }else if(recordTypeId.equals("1")) { // Report
//				 bodyHeader="<table><tr><td>Dear Sir / Madam, </td></tr><tr><td>This is to inform you, "+branchName+" sent "+noOfCount+" (total number of books) report books through "+courierName+""
//						 + " courier under AWB number "+awbString+" on "+dispatchDate+", please acknowledge and confirm the receipt</td></tr></table>";
//			 }else if(recordTypeId.equals("2")) { // Voucher
//				 bodyHeader="<table><tr><td>Dear Sir / Madam, </td></tr><tr><td>This is to inform you, "+branchName+" sent "+noOfCount+" (total number of books) voucher books  through "+courierName+""
//						 + " courier under AWB number "+awbString+" on "+dispatchDate+", please acknowledge and confirm the receipt</td></tr></table>";
//			 } 
//			 
//			 
//			 bodyFooter = "<table>" + 
//			 		"<tr><td>Regards,</td></tr>" + 
//			 		"<tr><td>Suryoday Small Finance Bank Ltd </td></tr></table>" ;
//			 
//			 completeMessage = bodyHeader + bodyFooter;
//			
//			 InventoryController inventoryController = new InventoryController();
//			 EmailConfigurationBean emailConfigurationBean = inventoryController.fetchEmailConfigurationBean();
//			 MailSender mailSender = new MailSender();
//			 
//			 System.out.println("to Email IDs :" + emailIds);
//
//			 if(ResourceUtil.getKeyValue("localTesting").equals("true")) {
//				 return mailSender.sendEmailthoroughgmail(completeMessage, emailSub, emailIds);
//
//			 }else {
//				 return mailSender.sendMailWithAllDetails(completeMessage, emailSub, emailIds, emailConfigurationBean.getFromEmailId(), 
//						 emailConfigurationBean.getFromPassword(), emailConfigurationBean.getFromHost(), emailConfigurationBean.getPort());
//			 }
//		}
//		
//		
//		
}
