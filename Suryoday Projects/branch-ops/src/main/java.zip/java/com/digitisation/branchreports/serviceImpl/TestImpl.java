package com.digitisation.branchreports.serviceImpl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.*;
import com.digitisation.branchreports.repository.ReportMasterRepository;
import com.digitisation.branchreports.service.ReportMasterService;
import com.digitisation.branchreports.service.TestService;

import javassist.expr.NewArray;


@Service

public class TestImpl {
	public static void main(String[] args) throws ParseException {
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

	
		String s = df.format(new Date());
		System.out.println(s);

	}
	
	


}
