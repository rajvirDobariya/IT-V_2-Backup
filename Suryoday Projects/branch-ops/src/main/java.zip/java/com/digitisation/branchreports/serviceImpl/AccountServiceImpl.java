package com.digitisation.branchreports.serviceImpl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.model.LoanAccountsData;
import com.digitisation.branchreports.model.LoanAccountsData2;
import com.digitisation.branchreports.model.LoanDocuments;
import com.digitisation.branchreports.repository.AccountsRepository;
import com.digitisation.branchreports.repository.AccountsRepository2;
import com.digitisation.branchreports.repository.BatchRepository;
import com.digitisation.branchreports.repository.LoanAccountsRepository;
import com.digitisation.branchreports.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountsRepository accountsRepository;
	
	@Autowired
	private AccountsRepository2 accountsRepository2;
	
	
	@Autowired
	private LoanAccountsRepository loanAccountsRepository;
	
	@Autowired
	private BatchRepository batchRepository;
	
	@Autowired
	public void setAccountsRepository(AccountsRepository accountsRepository) {
		this.accountsRepository = accountsRepository;
	}
	
	@Override
	public String uploadAccountsFile(MultipartFile[] uploadingFiles) {
		// TODO Auto-generated method stub
		
		LoanAccountsData2 loanAcc= null;
		List<LoanAccountsData2> data = new ArrayList<>();
		
		//System.out.println("Inside Loan account upload");
		for (MultipartFile multipartFile : uploadingFiles) {
			
			
			int i = 0;
			try (Workbook wb = WorkbookFactory.create(multipartFile.getInputStream());) {
				
						DataFormatter dataFormatter = new DataFormatter();
						Sheet sheet = wb.getSheetAt(0);
						Cell cell;
						 System.out.println("\n\nIterating over Rows and Columns using Iterator\n");
					        Iterator<Row> rowIterator = sheet.rowIterator();
					        while (rowIterator.hasNext()) {
					            Row row = rowIterator.next();
					            loanAcc = new LoanAccountsData2();
					            int error = 0;
					            
					            if(row == null){
									continue;
								}
					            if(row.getRowNum() == 0) {
					            	continue;
					            }
					         // Now let's iterate over the columns of the current row
					            					                
					            cell = row.getCell(0);
					            if(cell != null) {
					            
					            	String branchId = dataFormatter.formatCellValue(cell);
					            	loanAcc.setBranchCode(branchId);
					                System.out.print(branchId+": \t");
					            }
					            else {
					            
					            	
					            }
					            
					            cell = row.getCell(1);
					            if(cell != null) {
					            
					            	String branchName = dataFormatter.formatCellValue(cell);
					               System.out.print(branchName+":1 \t");
					                loanAcc.setBranchName(branchName);
					               
					            }
					            else {
					            	
					            }
					            
					            cell = row.getCell(2);
					            if(cell != null) {
					            
					            	String stateName = dataFormatter.formatCellValue(cell);
					            	System.out.print(stateName+":2 \t");
					            	loanAcc.setStateName(stateName);
										                
					            }
					            else {
					            	error++;
					            	
					            }
					            cell = row.getCell(3);
					            if(cell != null) {
					            
					            	String region = dataFormatter.formatCellValue(cell);
					               System.out.print(region+":3 \t");
					                loanAcc.setDwRegion(region);
					            }
					            else {
					            	error++;
					            }
					            
					            cell = row.getCell(4);
					            if(cell != null) {
					            
					            	String accountId = dataFormatter.formatCellValue(cell);
					               System.out.print(accountId+":"+cell.getCellType()+"\t");
					                loanAcc.setDwAccountId(accountId);
					            }else {
					            	
					            }
					            
					            cell = row.getCell(5);
					            if(cell != null) {
					            
					            	String name = dataFormatter.formatCellValue(cell);
					               System.out.print(name+":"+cell.getCellType()+"\t");
					                loanAcc.setDwName(name);
					            }
					            else {
					            	
					            }
					            
					            cell = row.getCell(6);
					            if(cell != null) {
					            
					            	String centerId = dataFormatter.formatCellValue(cell);
					               System.out.print(centerId+":"+cell.getCellType()+"\t");
					                loanAcc.setDwCenterId(centerId);
					            }
					            else {
					           
					     
					            }
					            cell = row.getCell(7);
					            if(cell != null) {
					            
					            	String centerName = dataFormatter.formatCellValue(cell);
					               System.out.print(centerName+":"+cell.getCellType()+"\t");
					                loanAcc.setDwCenter(centerName);
					            }
					            else {
					            	
					   
					            }
					            
					            cell = row.getCell(8);
					            if(cell != null) {
					            
					            	String clientId = dataFormatter.formatCellValue(cell);
					               System.out.print(clientId+":"+cell.getCellType()+"\t");
					                loanAcc.setDwClientId(clientId);
					            }
					            else {
					            	
					            	
					            }
					            cell = row.getCell(9);
					            if(cell != null) {
					            
					            	String creaditOfficer = dataFormatter.formatCellValue(cell);
					               System.out.print(creaditOfficer+":"+cell.getCellType()+"\t");
					                loanAcc.setDwCreditOfficer(creaditOfficer);
					            }else {
					            	
					            	
					            }
					            
					            cell = row.getCell(10);
					            if(cell != null) {
					            
					            	String disDate = dataFormatter.formatCellValue(cell);
					               System.out.print(disDate+":"+cell.getCellType()+"\t");
					                SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
					                java.util.Date date = sdf1.parse(disDate);
					   					                
					                loanAcc.setDwDisbDate(date);
					            }else {
					            	
					            	
					            }
					            
					            cell = row.getCell(11);
					            if(cell != null) {
					            	String disAmount = dataFormatter.formatCellValue(cell);
					               System.out.print(disAmount+":"+cell.getCellType()+"\t");
					                loanAcc.setDwDisbAmount(Double.parseDouble(disAmount));
					            }else {
					            	error++;
					            	
					            }
					            
					            cell = row.getCell(12);
					            if(cell != null) {
					            	String appFileNo = dataFormatter.formatCellValue(cell);
					               System.out.print(appFileNo+":"+cell.getCellType()+"\t");
					                loanAcc.setDwAppFileNo(appFileNo);
					            }else {
					            	
					            	
					            }
					            
					            cell = row.getCell(13);
					            if(cell != null) {
					            	String product = dataFormatter.formatCellValue(cell);
					            	
					               System.out.print(product+":"+cell.getCellType()+"\t");
					                /*SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yyyy");
					                java.util.Date date = sdf1.parse(new Date());
					                java.sql.Date disbDate = new java.sql.Date(date.getTime());*/
					                loanAcc.setProduct(product);
					            }else {
					            	
					            	
					            }
					           
					            i++;  
					            
					            if(error == 0) {
					            	data.add(loanAcc);
					            }
					           System.out.println(error);    
					        }
					        
					        
					        
					       //add to list					        
					        
				}catch(Exception e) {
					e.printStackTrace();
				}
			System.out.println(data.size());	
			
			for(int j=0; j<= data.size();j++) {
			accountsRepository2.getLoanAccountsDataByDwAccountIds(data.get(j).getDwAccountId());
		
			if(loanAcc != null) {
			
			List<LoanAccountsData2> savedList = accountsRepository2.saveAll(data);
			if(savedList != null) {
				return "Data Uploaded Successfully";
			}
			}
			}
			 return "Opps ! Problem uploading data";
			
				
			}
//		System.out.println(data.size());	
//		
//		accountsRepository2.getLoanAccountsDataByDwAccountId(loanAcc.getDwAccountId());
//	
//		if(loanAcc != null) {
//		
//		List<LoanAccountsData2> savedList = accountsRepository2.saveAll(data);
//		if(savedList != null) {
//			return "Data Uploaded Successfully";
//		}
//		}
//		 return "Opps ! Problem uploading data";
		return "Data Uploaded Successfully";
	}

	@Override
	public LoanAccountsData getAccountByAcNo(String accountNumber) {
		System.out.println("In implementation :"+accountNumber);
		return accountsRepository.getLoanAccountsDataByDwAccountId(accountNumber);
	}
	
	@Override
	public LoanDocuments updateDocument(LoanDocuments loanDocuments) {
		return accountsRepository.saveAndFlush(loanDocuments);
	}


//	@Override
//	public List<LoanAccounts> updateBatch1(LoanAccounts loanAccounts) {		
//	return (List<LoanAccounts>) loanAccountsRepository.saveAndFlush(loanAccounts);
//	}
//
	@Override
	public LoanAccounts updateBatch1(LoanAccounts loanAccounts) {
		return loanAccountsRepository.saveAndFlush(loanAccounts);		
	}



//	@Override
//	public List<LoanAccounts> updateStatus( String dwAccountId, String status) {
//
//		return batchRepository.updateStatus(dwAccountId, status);
//	}
}

