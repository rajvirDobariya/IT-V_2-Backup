package com.digitisation.branchreports.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.Branch;
import com.digitisation.branchreports.repository.BranchRepository;
import com.digitisation.branchreports.service.BranchService;

@Service
public class BranchServiceImpl implements BranchService {

	private BranchRepository branchRepository;
	
	@Autowired
	public void setBranchRepository(BranchRepository branchRepository) {
		this.branchRepository = branchRepository;
	}
	
	@Override
	public List<Branch> getAllBranch() {
		return branchRepository.findAll();
	}

	@Override
	public Branch getBranchByBranchCode(String branchCode) {
		return branchRepository.findByBranchCode(branchCode);
	}

	@Override
	public Branch getBranchByBranchName(String branchName) {
		// TODO Auto-generated method stub
		return branchRepository.findByBranchName(branchName);
	}

}
