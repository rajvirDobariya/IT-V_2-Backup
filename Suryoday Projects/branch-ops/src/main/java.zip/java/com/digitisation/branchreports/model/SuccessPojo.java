package com.digitisation.branchreports.model;

public class SuccessPojo {
	
	private int statuscode;
	private String statusdata;

	public String getStatusdata() {
		return statusdata;
	}

	public void setStatusdata(String statusdata) {
		this.statusdata = statusdata;
	}

	public int getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}

	public SuccessPojo(int statuscode, String statusdata) {
		super();
		this.statuscode = statuscode;
		this.statusdata = statusdata;
	}

	




}
