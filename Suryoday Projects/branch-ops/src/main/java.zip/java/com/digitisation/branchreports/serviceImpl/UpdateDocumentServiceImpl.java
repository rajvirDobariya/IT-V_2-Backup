package com.digitisation.branchreports.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.DocumentMaster;
import com.digitisation.branchreports.model.UpdateDocument;
import com.digitisation.branchreports.repository.DocumentMasterRepository;
import com.digitisation.branchreports.repository.UpdateDocumentRepository;
import com.digitisation.branchreports.service.UpdateDocumentService;

@Service
public class UpdateDocumentServiceImpl implements UpdateDocumentService{
	
	@Autowired
	private UpdateDocumentRepository updateDocumentRepository;
	
	@Autowired
	public void setUpdateDocumentRepository(UpdateDocumentRepository updateDocumentRepository) {
		this.updateDocumentRepository = updateDocumentRepository;
	}
	
	
//end
	@Override
	public List<UpdateDocument> getDocumentByAcNo(String accountNumber) {
		// TODO Auto-generated method stub
		return updateDocumentRepository.getDataByAccountId(accountNumber);
	}
	@Override
	public int updateDocumentsData(String updateAccountId, String documentName, boolean selectColumn, String status) {
		// TODO Auto-generated method stub
		return updateDocumentRepository.updateDocumentsData(updateAccountId,documentName,selectColumn,status);
	}


//	@Override
//	public int updateDocumentsData(String updateAccountId, String documentName, boolean selectColumn,String status) {
//		// TODO Auto-generated method stub
//		return updateDocumentRepository.updateDocumentsData(updateAccountId,documentName,selectColumn,status);
//	}

	@Override
	public int deleteDocumentById(String updateAccountId) {
		return updateDocumentRepository.removeAccountFromBatch(updateAccountId);
	}

	@Override
	public List<UpdateDocument> getAllDocuments() {
		return updateDocumentRepository.findAll();
	}


	@Override
	public UpdateDocument updateDocuments(UpdateDocument updateAccount) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public UpdateDocument getAccountData(String accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}


//	@Override
//	public List<UpdateDocument> deleteDocumentById(String updateAccountId) {
//		
//		return updateDocumentRepository.removeAccountFromBatch(updateAccountId);
//		 
//}


	
}
