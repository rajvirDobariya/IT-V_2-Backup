package com.digitisation.branchreports.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "BranchUserMaker")

public class BranchUserMakerModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "rep_id")
	private RepMaster repmaster;

	@OneToOne(mappedBy = "branchusermakermodel", cascade = CascadeType.ALL)
	private BranchChecker branchcheker;

	public BranchChecker getBranchcheker() {
		return branchcheker;
	}

	public void setBranchcheker(BranchChecker branchcheker) {
		this.branchcheker = branchcheker;
	}

	public RepMaster getRepmaster() {
		return repmaster;
	}

//	public void setRepmaster(RepMaster repmaster) {
//		this.repmaster = repmaster;
//	}

	private String status;
	private String branchname;
	private String reportname;
	private String dataavailable;
	private String dataverified;
	private String frequency;
	private String createdby;
	private String filename;
	private String reportstatus;
	private String checkercomments;

	public String getCheckercomments() {
		return checkercomments;
	}

	public void setCheckercomments(String checkercomments) {
		this.checkercomments = checkercomments;
	}

	public String getReportstatus() {
		return reportstatus;
	}

	public void setReportstatus(String reportstatus) {
		this.reportstatus = reportstatus;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getDataavailable() {
		return dataavailable;
	}

	public void setDataavailable(String dataavailable) {
		this.dataavailable = dataavailable;
	}

	public String getDataverified() {
		return dataverified;
	}

	public void setDataverified(String dataverified) {
		this.dataverified = dataverified;
	}

	public String getReportname() {
		return reportname;
	}

	public void setReportname(String reportname) {
		this.reportname = reportname;
	}

	@Lob
	@Column(name = "`uploadfile`")
	private byte[] uploadfile;

	@Temporal(TemporalType.DATE)
	private Date creationdate;

	@Temporal(TemporalType.DATE)
	private Date lastdate;

	public Date getLastdate() {
		return lastdate;
	}

	public void setLastdate(Date lastdate) {
		this.lastdate = lastdate;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBranchname() {
		return branchname;
	}

	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}

	public byte[] getUploadfile() {
		return uploadfile;
	}

	public void setUploadfile(byte[] uploadfile) {
		this.uploadfile = uploadfile;
	}

	public Date getCreationdate() {
		return creationdate;
	}

	public void setCreationdate(Date creationdate) {
		this.creationdate = creationdate;
	}

	public BranchUserMakerModel(String status, String branchname, String reportname, Date creationdate,
			String frequency, String createdby) {
		super();
		this.status = status;
		this.branchname = branchname;
		this.reportname = reportname;

		this.creationdate = creationdate;
		this.frequency = frequency;
		this.createdby = createdby;

	}

	public BranchUserMakerModel() {

	}

}
