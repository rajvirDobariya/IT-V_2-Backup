package com.digitisation.branchreports.service;

import java.util.List;

import com.digitisation.branchreports.model.Branch;

public interface BranchService {

	public List<Branch> getAllBranch();
	public Branch getBranchByBranchCode(String branchCode);
	public Branch getBranchByBranchName(String branchName);
}
