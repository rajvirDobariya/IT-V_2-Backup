package com.digitisation.branchreports.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Batch implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long batchId;
	
	private String createdBy;
	private String barCode;
	private String centerId;
	private String createdAt;
	private String status;
	private String awbNo;
	private String comments;
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	private String crownBoxNo;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "center_doc_id")
	@JsonIgnoreProperties("batch")
	private CenterDocuments centerDocuments;


	
	@OneToMany(cascade = CascadeType.PERSIST,fetch = FetchType.EAGER)
	@JoinColumn(name = "batch_id")
	@JsonIgnoreProperties("batch")
	private List<LoanAccounts> loanAccounts = new ArrayList<>();
	



	public Batch() {
	}

	public long getBatchId() {
		return batchId;
	}

	public void setBatchId(long batchId) {
		this.batchId = batchId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getBarCode() {
		return barCode;
	}

	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	public String getCenterId() {
		return centerId;
	}

	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAwbNo() {
		return awbNo;
	}

	public void setAwbNo(String awbNo) {
		this.awbNo = awbNo;
	}

	public String getCrownBoxNo() {
		return crownBoxNo;
	}

	public void setCrownBoxNo(String crownBoxNo) {
		this.crownBoxNo = crownBoxNo;
	}

	public CenterDocuments getCenterDocuments() {
		return centerDocuments;
	}

	public void setCenterDocuments(CenterDocuments centerDocuments) {
		this.centerDocuments = centerDocuments;
	}

	public List<LoanAccounts> getLoanAccounts() {
		return loanAccounts;
	}

	public void setLoanAccounts(List<LoanAccounts> loanAccounts) {
		this.loanAccounts = loanAccounts;
	}

	

}
