package com.digitisation.branchreports.service;
import java.util.List;

import com.digitisation.branchreports.model.CenterDocumentMaster;


public interface CentralDocumentMasterService {
	
	public List<CenterDocumentMaster> getAllCenterDocuments();
	public CenterDocumentMaster addDocumentToCentre(CenterDocumentMaster document);
	public 	void deleteDocument(long documentId);


}
