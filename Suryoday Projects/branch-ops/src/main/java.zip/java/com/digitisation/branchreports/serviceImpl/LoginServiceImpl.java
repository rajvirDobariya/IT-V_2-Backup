package com.digitisation.branchreports.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.LoginDetails;
import com.digitisation.branchreports.repository.LoginRepository;
import com.digitisation.branchreports.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService{
	@Autowired
	private LoginRepository loginRepository;

	@Override
	public LoginDetails getToken(String userName, String passWord) {
		// TODO Auto-generated method stub
		return loginRepository.getToken(userName,passWord);
	}

//	@Override
//	public LoginDetails getToken(LoginDetails loginDetails) {
//		// TODO Auto-generated method stub
//		return loginRepository.getToken(loginDetails);
//	}

	


	
	

}
