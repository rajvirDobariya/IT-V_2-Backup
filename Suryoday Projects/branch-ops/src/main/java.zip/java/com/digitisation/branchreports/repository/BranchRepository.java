package com.digitisation.branchreports.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.digitisation.branchreports.model.Branch;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Long> {
	
	public Branch findByBranchCode(String branchCode);
	public Branch findByBranchName(String branchName);

}
