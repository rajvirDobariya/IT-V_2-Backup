package com.digitisation.branchreports.service;

import java.util.List;

import com.digitisation.branchreports.model.*;


public interface ReportMasterService {

	
	public List<RepMaster> getalldata();
	public int updatereport(BranchUserMakerModel bkm);
	public int deletereportbyname(RepMaster repmaster);

	public RepMaster getreportbyname(String reportname);

}
