package com.digitisation.branchreports.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.CenterDocumentMaster;
import com.digitisation.branchreports.model.DocumentMaster;
import com.digitisation.branchreports.repository.DocumentMasterRepository;
import com.digitisation.branchreports.service.CentralDocumentMasterService;
import com.digitisation.branchreports.service.DocumentService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class DocumentMasterController {
	
	private DocumentService documentService;
	@Autowired
	private CentralDocumentMasterService centerdocumentService;

	

	@Autowired
	public void setDocumentService(DocumentService documentService) {
		this.documentService = documentService;
	}
	@Autowired
	private DocumentMasterRepository documentRepository;
	
	@PostMapping("/getAllDocuments")
	public List<DocumentMaster> getAllDocumentsData(){
		return documentService.getAllDocuments();
	}
	
	@PostMapping("/addDocument")
	public String addDocuments(@RequestBody DocumentMaster documentName) {
	
		String status="";
		DocumentMaster docMaster=null;
		CenterDocumentMaster cm=	documentName.getCenterDocumentMaster();
		docMaster=documentService.addDocument(documentName);
		   System.out.println("documentName.getCenterDocumentMaster() "+documentName.getCenterDocumentMaster().getCenterDocumentName());
		   System.out.println("****docMaster*** "+docMaster.toString());
		   centerdocumentService.addDocumentToCentre(cm);

//		
		if(docMaster!=null )
		{
			status="Data inserted properly !";
					
		}
		else
		{
			status="Error inserting data !";
		}
		
		return status;
	   
		
	}
	
	@PostMapping("/deleteDocumentById")
    public void delete(@RequestBody DocumentMaster documentMaster) {
		
		long docId = documentMaster.getDocumentId();

		documentService.deleteDocument(docId);
 }

	
	
    }


