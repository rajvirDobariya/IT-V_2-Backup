package com.digitisation.branchreports.serviceImpl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.repository.BranchUserMakerRepository;
import com.digitisation.branchreports.service.BranchUserMakerService;

@Service
public class BranchUserMakerServiceImpl implements BranchUserMakerService {
	@Autowired
	private BranchUserMakerRepository branchusermakerrepos;

	@Override
	public int storeFile(String reportname, String status, String branchcodename, Date currentdate, MultipartFile file,
			String dataavailable, String dataverified, String filename) {
		try {

			return branchusermakerrepos.updatereport(file.getBytes(), currentdate, reportname, dataavailable,
					dataverified, status, filename);

		} catch (Exception e) {

			System.out.println("Exception exception" + e.getMessage());
			return 0;
		}

	}

	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public BranchUserMakerModel addreport(BranchUserMakerModel reportmas) {
		return branchusermakerrepos.saveAndFlush(reportmas);
	}

	@Override
	public List<BranchUserMakerModel> getreports(BranchUserMakerModel bkm) {

		Calendar cal = Calendar.getInstance();
		Integer val = 0;
		try {
			val = branchusermakerrepos.validatedate(datestringreturn(new Date()));

		} catch (ParseException e) {

			e.printStackTrace();
		}

		List<String> frequencies = new ArrayList<String>();
		boolean monday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY;
		boolean sunday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
		int firstday = 1;

		if (monday) {

			// weekly and daily reports
			frequencies.add("Weekly");
			frequencies.add("Daily");
		}

		else if (!monday) {

			frequencies.add("Daily");

		}

		else if (monday && firstday == 1) {

			// daily,weekly,monthly
			frequencies.add("Weekly");
			frequencies.add("Daily");
			frequencies.add("Monthly");

		} else if (!monday && firstday == 1) {
			// daily,monthly
			frequencies.add("Daily");
			frequencies.add("Monthly");
		}
		if (val == 0 && !sunday) {

			insertdata();
		}
		return branchusermakerrepos.getreports(bkm.getStatus(), new Date(), 1, new Date());
	}

	public String datestringreturn(Date date) throws ParseException {

		return df.format(date);
	}

	@Override
	public int updatechecker(BranchUserMakerModel bm) {
		System.out.println(bm.getReportstatus());
		System.out.println(bm.getCheckercomments());

		if (bm.getReportstatus().equals("Accept")) {
			return branchusermakerrepos.acceptcheckstatus(bm.getReportstatus(), bm.getCheckercomments(),
					bm.getReportname(), bm.getFrequency(), bm.getLastdate());
		} else {
			return branchusermakerrepos.rejectcheckstatus(null, bm.getCheckercomments(),
					bm.getReportstatus(), bm.getReportname(), bm.getFrequency(), bm.getLastdate());

		}
	}

	@Override
	public int insertdata() {
		String status = "Not Submitted";
		try {

			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			Date today = c.getTime();
			String todayAsString = df.format(today);
			Calendar lastday = Calendar.getInstance();
			List<BranchUserMakerModel> branchmakeralldata = branchusermakerrepos.findAll();

			for (int i = 0; i < branchmakeralldata.size(); i++) {
				String reportname = branchmakeralldata.get(i).getReportname();
				long repid = branchmakeralldata.get(i).getRepmaster().getReportid();

				String frequency = branchmakeralldata.get(i).getFrequency();

				String lastdateasstring = df.format(branchmakeralldata.get(i).getLastdate());
				String reportenddate = df.format(branchmakeralldata.get(i).getRepmaster().getReportenddate());

				// This loop is used for the BOD
				if (branchmakeralldata.get(i).getRepmaster().getReportextracted().equals("BOD")
						&& !branchmakeralldata.get(i).getStatus().equals("Reject")) {
					System.out.println("Reportname : " + reportname);

					lastday.setTime(new Date());
					if (frequency.equals("Daily")) {
						lastday.add(Calendar.DATE, 1);
						Date lastdate = lastday.getTime();
						String lastdayasString = df.format(lastdate);
						System.out.println("------------------last day String" + lastdayasString);
						branchusermakerrepos.insertingdata(reportname.trim(), frequency, todayAsString, status,
								lastdayasString, repid);
					}
					if (frequency.equals("Weekly")) {
						lastday.add(Calendar.WEEK_OF_MONTH, 1);
						Date lastdate = lastday.getTime();
						String lastdayasString = df.format(lastdate);
						branchusermakerrepos.insertingdata(reportname.trim(), frequency, todayAsString, status,
								lastdayasString, repid);
					}
					if (frequency.equals("Monthly")) {

						lastday.add(Calendar.MONTH, 1);
						Date lastdate = lastday.getTime();
						String lastdayasString = df.format(lastdate);
						//
						branchusermakerrepos.insertingdata(reportname.trim(), frequency, todayAsString, status,
								lastdayasString, repid);
					}
				}
//				// This Loop is for exception check if lastdate is less than today then status
//				// will be changed to exception
				else if (df.parse(lastdateasstring).before(df.parse(todayAsString))
						&& branchmakeralldata.get(i).getStatus().equals("Not Submitted")) {

					branchusermakerrepos.updateexception("Exception", branchmakeralldata.get(i).getReportname(),
							branchmakeralldata.get(i).getFrequency(), branchmakeralldata.get(i).getCreationdate(),
							branchmakeralldata.get(i).getLastdate());
				}

				// if reportdate is end
				else if (df.parse(reportenddate).equals(df.parse(todayAsString))) {
					branchusermakerrepos.updateexception("Disabled", branchmakeralldata.get(i).getReportname(),
							branchmakeralldata.get(i).getFrequency(), branchmakeralldata.get(i).getCreationdate(),
							branchmakeralldata.get(i).getLastdate());
				}

				// This Loop is used for EOD because in EOD lastdate and creationdate is same
				if (branchmakeralldata.get(i).getRepmaster().getReportextracted().equals("EOD") && branchmakeralldata
						.get(i).getCreationdate().equals(branchmakeralldata.get(i).getLastdate())) {
					System.out.println("Report name : " + reportname);
					System.out.println("Today String as string : " + todayAsString);
					branchusermakerrepos.insertingdata(reportname.trim(), frequency, todayAsString, status,
							todayAsString, repid);
				}
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			return 1;
		}
	}

	@Override
	public List<BranchUserMakerModel> retrievereports(String status, Date startdate, Date lastdate) {

		return branchusermakerrepos.retrievereportsbydate(status, new Date(), new Date());
	}

	@Override
	public List<BranchUserMakerModel> allexceptionreport(String status) {
		return branchusermakerrepos.allexceptionreports(status, 1);
	}

}
