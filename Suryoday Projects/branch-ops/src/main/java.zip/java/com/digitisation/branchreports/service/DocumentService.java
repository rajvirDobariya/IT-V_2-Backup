package com.digitisation.branchreports.service;

import java.util.List;
import java.util.Optional;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.Branch;
import com.digitisation.branchreports.model.CenterDocumentMaster;
import com.digitisation.branchreports.model.DocumentMaster;

public interface DocumentService {
	
	
	public List<DocumentMaster> getAllDocuments();
	public DocumentMaster addDocument(DocumentMaster document);
	//public List<CenterDocumentMaster> getAllCenterDocuments();
	//public CenterDocumentMaster addDocumentToCentre(CenterDocumentMaster document);
	public 	void deleteDocument(long documentId);
	//public 	void deleteDocument1(long documentId);
	public Iterable<DocumentMaster> findAll();
	

}
