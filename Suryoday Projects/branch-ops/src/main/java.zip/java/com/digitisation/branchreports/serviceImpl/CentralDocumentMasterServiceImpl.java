package com.digitisation.branchreports.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.CenterDocumentMaster;
import com.digitisation.branchreports.repository.CenterDocumentRepository;
import com.digitisation.branchreports.service.CentralDocumentMasterService;

@Service
public class CentralDocumentMasterServiceImpl implements CentralDocumentMasterService {
	@Autowired
	private CenterDocumentRepository centerDocumentRepository;
	
	@Override
	public List<CenterDocumentMaster> getAllCenterDocuments() {
		return centerDocumentRepository.findAll();
	}

	@Override
	public CenterDocumentMaster addDocumentToCentre(CenterDocumentMaster cdocument) {
		return centerDocumentRepository.save(cdocument);	
		}

	@Override
	public void deleteDocument(long documentId) {
		 centerDocumentRepository.deleteById(documentId);

	}


}
