package com.digitisation.branchreports.controller;




import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.LoanAccountsData;
import com.digitisation.branchreports.service.AccountService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ReadExcelController {
	
	private AccountService accountService;
	
	

	@Autowired
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	
	
//	@RequestMapping(value = "/fetchRetrivalRecordPendingForCSU")
//	List<LoanAccountsData> fetchRetrivalRecordPendingForCSU(@RequestParam String recordTypeId){
//		List<LoanAccountsData> LoanAccountsDataList = new ArrayList<>();
//		
//		/*String modifiedStartDate = "", modifiedEndDate = "";
//
//		if(startDate != null && startDate != "") {
//			String str[] = startDate.split("-");
//			if(str.length >= 3) {
//				modifiedStartDate = str[2]+ "-" + str[1] + "-" +str[0]; 
//			}
//		}
//		
//		if(endDate != null && endDate != "") {
//			String str[] = endDate.split("-");
//			if(str.length >= 3) {
//				modifiedEndDate = str[2]+ "-" + str[1] + "-" +str[0];
//			}
//		}*/
//		
//		if(recordTypeId != "" && recordTypeId != null) {
//			String sql = "select * from tbl_branch_documents_record_retrival ret , "
//					+ " tbl_branch_documents_records rec "
//					+ " where ret.retrival_status = '"+BranchEnum.REQUESTED_FOR_RECORD_RETRIVAL.value()+"'"
//					+ " and ret.branch_document_record_id = rec.banch_document_record_id and record_type_id = "+recordTypeId+"";
//			
//			
//			try(Connection conn  = ConnectionUtil.getConnection();
//					Statement stmt = conn.createStatement();
//					ResultSet rs = stmt.executeQuery(sql)){
//				while(rs.next()) {
//					LoanAccountsData LoanAccountsData = new LoanAccountsData();
//					
//					// branch document record start
//					BranchDocumentRecord branchDocumentRecord = new BranchDocumentRecord();
//					branchDocumentRecord.setBranchCode(rs.getString("branch_code"));
//					branchDocumentRecord.setBranchDocumentRecordID(rs.getString("banch_document_record_id"));
//					branchDocumentRecord.setDocumentType(rs.getString("document_type"));
//					branchDocumentRecord.setBarcodeNo(rs.getString("barcode_no"));
//					branchDocumentRecord.setAcNo(rs.getString("ac_no"));
//					branchDocumentRecord.setAcTitle(rs.getString("ac_title"));
//					branchDocumentRecord.setAwbNo(rs.getString("AWB_no"));
//					branchDocumentRecord.setCourierName(rs.getString("courier_name"));
//					if(rs.getDate("dispatch_date")!= null) {
//						branchDocumentRecord.setDispatchDate(DateUtil.getStringFormattedDate(rs.getDate("dispatch_date"),"dd-MM-yyy"));
//					}
//					branchDocumentRecord.setStatus(rs.getString("status"));
//					branchDocumentRecord.setIsActive(rs.getString("is_active"));
//					branchDocumentRecord.setBranchName(rs.getString("branch_name"));
//					branchDocumentRecord.setCustomerNo(rs.getString("customer_no"));
//					branchDocumentRecord.setAcTitle(rs.getString("ac_title"));
//					
//					if(rs.getDate("ac_open_date")!= null) {
//						branchDocumentRecord.setAcOpenDate(DateUtil.getStringFormattedDate(rs.getDate("ac_open_date"),"dd-MM-yyy"));
//					}
//					
//					branchDocumentRecord.setDocumentType(rs.getString("document_type"));
//					branchDocumentRecord.setSchemeCode(rs.getString("scheme_code"));
//					branchDocumentRecord.setAcStat(rs.getString("ac_stat"));
//					branchDocumentRecord.setFileBarcode(rs.getString("file_barcode"));
//					branchDocumentRecord.setCartonBarcode(rs.getString("carton_barcode"));
//					
//					if(rs.getDate("receipt_date")!= null) {
//						branchDocumentRecord.setReceiptDate(DateUtil.getStringFormattedDate(rs.getDate("receipt_date"),"dd-MM-yyy"));
//					}
//					
//					branchDocumentRecord.setReceiptBy(rs.getString("receipt_by"));
//					branchDocumentRecord.setDispatchBy(rs.getString("dispatch_by"));
//					branchDocumentRecord.setRecordTypeId(rs.getString("record_type_id"));
//					branchDocumentRecord.setNoOfBook(rs.getString("no_of_book"));
//					if(rs.getDate("report_date")!= null) {
//						branchDocumentRecord.setReportDate(DateUtil.getStringFormattedDate(rs.getDate("report_date"),"dd-MM-yyy"));
//					}
//					branchDocumentRecord.setRefBranchDocumentRecordId(rs.getString("ref_branch_document_record_id"));
//					// branch document record end
//					
//					LoanAccountsData.setLoanAccountsDataID(rs.getString("branch_document_record_retrival_id"));
//					LoanAccountsData.setDocumentName(rs.getString("upload_document_name"));
//					LoanAccountsData.setRetrivalRequestBy(rs.getString("retrival_request_by"));
//					
//					if(rs.getDate("retirval_request_on")!= null) {
//						LoanAccountsData.setRetrivalRequestOn(DateUtil.getStringFormattedDate(rs.getDate("retirval_request_on"),"dd-MM-yyy"));
//					}
//					
//					LoanAccountsData.setActionBy(rs.getString("action_by"));
//					
//					if(rs.getDate("action_on")!= null) {
//						LoanAccountsData.setActionOn(DateUtil.getStringFormattedDate(rs.getDate("action_on"),"dd-MM-yyy"));
//					}
//					
//					LoanAccountsData.setRemarks(rs.getString("remarks"));
//					LoanAccountsData.setIsPhysicalCopyRequired(rs.getString("is_physical_copy_required"));
//					LoanAccountsData.setMailSentToVendor(rs.getString("mail_sent_to_vendor"));
//					
//					if(rs.getDate("document_received_on")!= null) {
//						LoanAccountsData.setDocumentReceivedOn(DateUtil.getStringFormattedDate(rs.getDate("document_received_on"),"dd-MM-yyy"));
//					}
//					
//					LoanAccountsData.setDocumentReceiveBy(rs.getString("document_received_by"));
//					LoanAccountsData.setStatus(rs.getString("retrival_status"));
//					LoanAccountsData.setIsPhysicalCopyRequired(rs.getString("is_physical_copy_required"));
//					LoanAccountsData.setBranchDocumentRecord(branchDocumentRecord);
//					LoanAccountsDataList.add(LoanAccountsData);
//				}
//			}catch(Exception e) {
//				LOGGER.error("Exception", e);
//			}
//		}
//		
//		return LoanAccountsDataList;
//	}
//	
}









