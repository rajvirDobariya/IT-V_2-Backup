package com.digitisation.branchreports.model;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="BranchUserChecker")
public class BranchChecker implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private String frequency;
	private String reportname;
	private String dataverified;
	private String dataavailable;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "branchmaker_id")
	private BranchUserMakerModel branchusermakermodel;
	
	
	public BranchUserMakerModel getBranchusermakermodel() {
		return branchusermakermodel;
	}
	public void setBranchusermakermodel(BranchUserMakerModel branchusermakermodel) {
		this.branchusermakermodel = branchusermakermodel;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getReportname() {
		return reportname;
	}
	public void setReportname(String reportname) {
		this.reportname = reportname;
	}
	public String getDataverified() {
		return dataverified;
	}
	public void setDataverified(String dataverified) {
		this.dataverified = dataverified;
	}
	public String getDataavailable() {
		return dataavailable;
	}
	public void setDataavailable(String dataavailable) {
		this.dataavailable = dataavailable;
	}
}
