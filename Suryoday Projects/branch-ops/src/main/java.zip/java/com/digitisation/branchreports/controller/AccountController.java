package com.digitisation.branchreports.controller;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.DocumentMaster;
import com.digitisation.branchreports.model.LoanAccountsData;
import com.digitisation.branchreports.model.LoanDocuments;
import com.digitisation.branchreports.service.AccountService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class AccountController {
	
	private AccountService accountService;
	
	

	@Autowired
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	
	@PostMapping("/getAccountByAcNo")
	public LoanAccountsData getLoanAccountByAcNo(@PathParam("accountNumber") String accountNumber) {
		System.out.println("In Controller :"+accountNumber);
		return accountService.getAccountByAcNo(accountNumber);
	}
	
	
	
	
	
	


	
//	public boolean checkIfAccountIdExist(String accountId)
//	{
//		boolean result= false;
//		
//		List<UpdateDocument> updateDocData = updateDocumentService.getDocumentByAcNo(accountId);
//		
//		System.out.print("updateDocData "+updateDocData.size());
//		
//		if(updateDocData.size()==0 ||updateDocData==null)
//		
//		{
//			result = false;
//		}
//		
//		else
//		{
//			result = true;
//		}
//		return result;
//		
//	}
//	
	
	
	
	@PostMapping("/uploadDocument")

	public ResponseEntity<LoanDocuments> updateDocument(@RequestBody LoanDocuments loanDocuments ) {
	if(loanDocuments != null) {
	accountService.updateDocument(loanDocuments);

	}
	else {
	return new ResponseEntity<LoanDocuments>(new LoanDocuments(),HttpStatus.NOT_ACCEPTABLE);
	}
	return new ResponseEntity<LoanDocuments>(accountService.updateDocument(loanDocuments),HttpStatus.CREATED);

	}

	
	
	
}









