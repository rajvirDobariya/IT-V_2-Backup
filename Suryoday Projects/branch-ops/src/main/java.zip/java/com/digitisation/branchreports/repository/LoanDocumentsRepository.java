package com.digitisation.branchreports.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.LoanAccounts;
import com.digitisation.branchreports.model.LoanDocuments;

@Repository
@Transactional
public interface LoanDocumentsRepository extends JpaRepository<LoanDocuments, Long> {


	
//	@Query("SELECT b FROM LoanDocuments b where b.accountId= :accountId")
//	LoanDocuments findByAccountId(@Param("accountId")String accountId);
	
	@Query("SELECT b FROM LoanDocuments b where b.accountId= :accountId and b.documentName= :documentName")
	LoanDocuments getOne(@Param("accountId")String accountId, @Param("documentName")String documentName);

//
//	@Modifying
//	  @Query("update LoanDocuments k set file= :file where k.accoutId= :accountId  and k.loanDocumentId= :loanDocumentId ")
//		int uploadExistingFile(String accountId, long loanDocumentId, byte[] file);

//	  int uploadExistingFile(@Param("loanDocumentId")long loanDocumentId,@Param("fileName")String fileName,@Param("file")byte[] file);

	@Modifying
	  @Query("update LoanDocuments k set file= :file where k.accountId= :accountId and  k.documentName = :documentName")
	 
	  int uploadExistingFile(@Param("file")byte[] file_one,@Param("accountId")String loanDoc,@Param("documentName")String name);


//	int uploadExistingFile(MultipartFile file, String loanDoc, String fileType, String name);


	

}
