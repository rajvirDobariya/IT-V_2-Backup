package com.digitisation.branchreports.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.LoanDocuments;
import com.digitisation.branchreports.repository.LoanDocumentsRepository;
import com.mysql.cj.jdbc.Blob;

import org.springframework.util.StringUtils;


@Service
public class LoanDocumentService {
	@Autowired
	private LoanDocumentsRepository loanDocumentRepository;
		InputStream inputStream = null;
		OutputStream out = null;
		String filepath ;
		LoanDocuments loandocuments;
			
	    public LoanDocuments storeFile(MultipartFile file ,String loanDoc, String fileType, String name)   //,String name
	    { 
//    	String name = StringUtils.cleanPath(file.getOriginalFilename());
//	    	String fileNames = "DisbursmentPhotograph";
//	    	String fileName = StringUtils.cleanPath(path)
	    	String fileName = fileType+"_"+loanDoc+"_"+name;
	    			
	    	try {
				inputStream = file.getInputStream();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	
	    	
//	    	InputStream inputStream = new FileInputStream(new File(filepath));
//	    	filepath =  new FileInputStream(new File(filepath));
//	    	byte[] buffer = new byte[inputStream.available()];
//	    	Statement.setBlob(inputStream);
//	    	inputStream.close();
//	    	Blob blob = inputStream
	    	
//			byte[] buffer = new byte[inputStream.available()];
		
//			 java.sql.Blob blob = new javax.sql.rowset.serial.SerialBlob(buffer);
//	    	LoanDocuments documents = new LoanDocuments();
	 	    LoanDocuments loanDocuments = null;
			
	 	    try {
				loanDocuments = new LoanDocuments(fileName ,file.getContentType(), file.getBytes(),loanDoc,name);
			} 
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return loanDocumentRepository.save(loanDocuments);

	    }

	    	
	    //upload documents data
		public int uploadDocumentsData(MultipartFile file,String loanDoc,String name ) throws IOException {
//			 storeFile(MultipartFile file ,String loanDoc, String fileType, String name)
			
			return loanDocumentRepository.uploadExistingFile(file.getBytes(), loanDoc, name);
		}
	    
//	    public LoanDocuments getFile(String fileName) {
//	        return loanDocumentRepository.findByFileName(fileName);
//   	
//           .orElseThrow(() -> new MyFileNotFoundException("File not found with id " + fileId));
//	    }

//		public LoanDocuments getFile(String fileName) {
//			// TODO Auto-generated method stub
//			return loanDocumentRepository.findByFileNames(fileName);
//		}
	  


	}


//@Autowired
//
//public LoanDocuments storeFile(MultipartFile file) throws IOException  {
//    // Normalize file name
//    String fileName = StringUtils.cleanPath(file.getOriginalFilename());
//
//   
////    LoanDocuments dbFile = new LoanDocuments(fileName, file.getBytes());
////	return loanDocumentRepository.save(dbFile);
//	try {
//		 if(fileName.contains("..")) {
////                throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
//            }
//		 
//		 LoanDocuments dbFile = new LoanDocuments(fileName, file.getBytes());
//	} catch (IOException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//	LoanDocuments dbFile = new LoanDocuments(fileName, file.getBytes());
//	return loanDocumentRepository.save(dbFile);
//}
//
//
////public DBFile getFile(String fileId) {
////    return loanDocumentRepository.findById(fileId)
////            .orElseThrow(() -> new MyFileNotFoundException("File not found with id " + fileId));
////}





