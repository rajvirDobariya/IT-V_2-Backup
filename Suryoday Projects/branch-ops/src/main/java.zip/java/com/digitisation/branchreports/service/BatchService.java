package com.digitisation.branchreports.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.Batch;
import com.digitisation.branchreports.model.LoanAccounts;

@Service
public interface BatchService {
	
	public Batch createBatch(Batch batch);
	public List<Batch> getAllBatches(String centerId,String createdBy);
	public Optional<Batch> getBatchById(long id);
	void deleteBatchById();
	public Batch updateBatch(Batch batch);
//	public LoanAccounts updateBatch1(LoanAccounts loanAccounts);
	public List<Batch> getBatchByCreatedBy(String createdBy);
	public List<Batch> getBatchPendingForApproval(String centerID);
	public List<Batch> getAllApprovedBatch(String status);
	public List<Batch> getBatchForProcessing();
	public List<Batch> getBatchForDispath();
	public List<Batch> getBatchForApproval(String centerId);
	public List<Batch> getBatchForDescrepancy(String centerId);
	public List<Batch> getBatchForRetrieval(String centerId);
	public List<Batch> getBatchForRetrieval1(String centerId, long batchId);

	
	

}
