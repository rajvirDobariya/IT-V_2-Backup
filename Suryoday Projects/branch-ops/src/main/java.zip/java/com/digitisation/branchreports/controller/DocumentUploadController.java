package com.digitisation.branchreports.controller;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.AbstractFileResolvingResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.LoanDocuments;
import com.digitisation.branchreports.repository.LoanDocumentsRepository;
import com.digitisation.branchreports.service.LoanDocumentService;
import com.mysql.cj.jdbc.Blob;

import java.util.Base64;
import java.util.List;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class DocumentUploadController {

	@Autowired
    private ServletContext servletContext;
	
	@Autowired
	private LoanDocumentsRepository loanDocumentsRepository;
	
	@Autowired
	private LoanDocumentService loanDocumentService;
	

	private String loanDocId;

	private File targetFile = null;
	
	@PostMapping("/upload-document")
	public String uploadDocuments(@RequestParam("id") String loanDocId,@RequestParam("fileType") String fileType,
			@RequestParam("file") MultipartFile uploadFile, @RequestParam("name") String name) //
	{
		String fileName = "";
		System.out.println("File Uploading for loan Account Id :"+loanDocId);
//		String filePath = "/opt/alfresco-community/FIS_Report";
//		String filePath = "C://Users//Keshav.R//Desktop//jlg_pdd_documents//";
	//	String filePath = "D://uploadedfiles//";
		String filePath = "/home/20513@suryodaybank.local/anurag/JLG-Images";
		InputStream inputStream = null;
		OutputStream out = null;	
		System.out.println("id ="+loanDocId);
		if(uploadFile != null) {
			try {
				inputStream = uploadFile.getInputStream();
				String tempName = uploadFile.getOriginalFilename();
				
				String fileExtension="";
				// Get file Name first
//				String fileName1=uploadFile.getName();
				
				LoanDocuments loanDoc =loanDocumentsRepository.getOne(loanDocId,name);	
				if (loanDoc != null) {
					
					updateExistingDocumentId(uploadFile, loanDocId,fileType, name);
					
				}
				else {
				
				// If fileName do not contain "." or starts with "." then it is not a valid file
				if(tempName.contains(".") && tempName.lastIndexOf(".")!= 0)
				{
					fileExtension=tempName.substring(tempName.lastIndexOf(".")+1);
				}
				
				String uName = fileType+"_"+loanDocId+"_"+name;
				
//				String tempName1 = "DisbursmentPhotograph";
//				fileName = fileType+"_"+loanDocId+"."+fileExtension; //+name+"
				targetFile = new File(filePath + File.separator + uName);
				byte[] buffer = new byte[inputStream.available()];
				inputStream.read(buffer);
				out = new FileOutputStream(targetFile);
				out.write(buffer);
				inputStream.close();
				
				
				  loanDocumentService.storeFile(uploadFile,loanDocId,fileType,name);//name

				
//				String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
//		                .path("/downloadFile/")
//		                .path()
//		                .toUriString();
//				
				
                
				if(out != null) {
					try {
						out.close();
					}catch(Exception e) {
						e.printStackTrace();
					}
				}
//				try {
//					 
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				
				
				}
				return "Document uploaded.";
			}catch(Exception e) {
				e.printStackTrace();
				return "Problem while uploading document.";
			}
			finally {
				if(out != null) {
					try {
						out.close();
					}catch(Exception e) {
						e.printStackTrace();
					}
					
				}
			}
		
		}

		return "No file uploaded";
		
	}
	
	@PostMapping("/updateExistingUploadDocument")
	public  String updateExistingDocumentId(@RequestParam("file") MultipartFile uploadFile,@RequestParam("id") String loanDocId,
			@RequestParam("fileType") String fileType,@RequestParam("name") String name)

	{
		LoanDocuments loanDocuments = null;
		
		String accountId= loanDocId;
		String documentName= name;
		MultipartFile file = uploadFile;
		
//		String filePath = "C://Users//Keshav.R//Desktop//jlg_pdd_documents//";
	//	String filePath = "D://uploadedfiles//";
		String filePath = "/home/20513@suryodaybank.local/anurag/JLG-Images";

		InputStream inputStream = null;
		OutputStream out = null;			
		if(uploadFile != null) {
			try {
				inputStream = uploadFile.getInputStream();
				String tempName = uploadFile.getOriginalFilename();
				
				String fileExtension="";
				// Get file Name first
//				String fileName1=uploadFile.getName();
				
				// If fileName do not contain "." or starts with "." then it is not a valid file
				if(tempName.contains(".") && tempName.lastIndexOf(".")!= 0)
				{
					fileExtension=tempName.substring(tempName.lastIndexOf(".")+1);
				}
				
				String uName = fileType+"_"+loanDocId+"_"+name;
				
//				String tempName1 = "DisbursmentPhotograph";
//				fileName = fileType+"_"+loanDocId+"."+fileExtension; //+name+"
				targetFile = new File(filePath + File.separator + uName);
				byte[] buffer = new byte[inputStream.available()];
				inputStream.read(buffer);
				out = new FileOutputStream(targetFile);
				out.write(buffer);
				inputStream.close();
//				fileType= "image/jpeg";

//				  loanDocumentService.storeFile(uploadFile,loanDocId,fileType,name);//name
				loanDocumentService.uploadDocumentsData(uploadFile,accountId,name);

				
//				String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
//		                .path("/downloadFile/")
//		                .path()
//		                .toUriString();
//				
                
				if(out != null) {
					try {
						out.close();
					}catch(Exception e) {
						e.printStackTrace();
					}
				}
//				try {
//					 
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				
				
				return "Document uploaded.";
			}catch(Exception e) {
				e.printStackTrace();
				return "Problem while uploading document.";
			}
			finally {
				if(out != null) {
					try {
						out.close();
					}catch(Exception e) {
						e.printStackTrace();
					}
					
				}
			}
			
			
			 

		}

		
		
		return "No file uploaded";

//		long loanDocumentId = loanDocuments.getLoanDocumentId();
			
	}
	

	//working***************************
	@GetMapping(value = "/viewDocuments",produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] getImage(@RequestParam("loanDocId") String loanDocId, @RequestParam("docName") String docName, HttpServletRequest request, HttpServletResponse response ) throws IOException {
//		String tempName = "/download.png";
//		showFlagType = "D/";
		byte[] b= new byte[0];
		byte[]c = new byte[0];
		String filename =" ";
//		String fileName = docName;

	LoanDocuments loanDoc = loanDocumentsRepository.getOne(loanDocId,docName);
	
	
	
	
		   
	c=  loanDoc.getFileOne();
		   
		   filename =    loanDocId+docName;
		   
//		  FileOutputStream fis = new FileOutputStream("C:/Users/Keshav.R/Desktop/jlg_pdd_documents/documents/"+filename);
	//	  FileOutputStream fis = new FileOutputStream("D:/uploadedfiles/ram/"+filename);
		  FileOutputStream fis = new FileOutputStream ("/home/20513@suryodaybank.local/anurag/SaveFromDb/"+filename);
		  fis.write(c);
		  
		 fis.close();
		  
		 response.setContentType("application/force-download");

//         response.setContentType("application/jpeg; charset=UTF-8");
//		byte[] bytes = loanDoc.getFile();

//		byte[] base64 = Base64.getEncoder().encodeToString(bytes);
//		 String url = "https://www.journaldev.com/sitemap.xml";
//		 String url= "file:///C:/Users/Keshav.R/Desktop/jlg_pdd_documents/documents/"+docName;
	//	 String url= "file:///D:/uploadedfiles/ram/"+docName;
		 String url= "/home/20513@suryodaybank.local/anurag/SaveFromDb/"+docName;
		 
		 
		 
	        
		try {
			
         //  c= downloadUsingNIO(url, "file:///D:/uploadedfiles/ram"+fileName);
//            file:{"D:/uploadedfiles/ram/sitemap.xml"};
            
 //          b= downloadUsingStream(url, "C:/Users/Keshav.R/Desktop/jlg_pdd_documents/documents/"+filename);
         //  b= downloadUsingStream(url, "D:/uploadedfiles/ram/"+filename);
			 b= downloadUsingStream(url, "/home/20513@suryodaybank.local/anurag/SaveFromDb/"+filename);
        }
		catch (FileNotFoundException e) { 
	           System.out.println("File does not exist"); 
	        } 
		catch (IOException e) {
            e.printStackTrace();
        }
		
		
		
		return b;
		
		
//	   byte[] imgFile = new ClassPathResource("D:/uploadedfiles/"+fileName) ;
//	   return loanDoc.getFile();

		
		
//		return bytes;
		
//		 Boolean documentName = loanDoc.getDisbursementPhotograh();
//		System.out.println("document name*********"+loanDoc);
//		 inputStream = new FileInputStream
	    
	
	    
//	    return ResponseEntity
//	            .ok()
//	            .contentType(MediaType.IMAGE_JPEG)
//	            .body(new InputStreamResource(imgFile.getInputStream()));
	}
	//*********************************
	

	
	
	private static byte[] downloadUsingStream(String urlStr, String file) throws IOException{
        //URL url = new URL(urlStr);
        byte[] buffer1 = new byte[0];
        
//        BufferedInputStream bis = new BufferedInputStream(url.openStream());
//        FileOutputStream fis = new FileOutputStream(file);
//        byte[] buffer = new byte[1024];
//        
//        int count=0;
//        while((count = bis.read(buffer,0,1024)) != -1)
//        {
//            fis.write(buffer, 0, count);
//           
//        }
//        
//        
//        fis.close();
//        bis.close();
//        
        
        
      try (InputStream is = new FileInputStream(file)) {
            
           buffer1 = new byte[is.available()];
            is.read(buffer1);
            
        
            
//            for (byte b: buffer1) {
//                
//                if (i % 10 == 0) {
//                    System.out.println();
//                }
//                
//                System.out.printf("%02x ", b);
//               
//                i++;
//            }
           

  		  is.close();
        }
      catch (FileNotFoundException e) { 
          System.out.println("File does not exist"); 
       } 
	catch (IOException e) {
       e.printStackTrace();
   }
      
      
      
//      JSONArray arr = new JSONArray(new String(bArr));
//      
//      String testV=new JSONObject(new String(responseBody)).toString();
      

   return buffer1;
      
    }

    private static byte[] downloadUsingNIO(String urlStr, String file) throws IOException {
        URL url = new URL(urlStr);
        byte[] buffer2 = new byte[0];
        ReadableByteChannel rbc = Channels.newChannel(url.openStream());
        FileOutputStream fos = new FileOutputStream(file);
        fos.getChannel().transferFrom(rbc, 0, Long.MAX_VALUE);
        
//        Blob blob = rs.getBlob(column);
//        InputStream in = blob.getBinaryStream();
        OutputStream out = new FileOutputStream(file);
        byte[] buff = new byte[4096];  // how much of the blob to read/write at a time
        int len = 0;

//        while ((len = in.read(buff)) != -1) {
//            out.write(buff, 0, len);
//        }
        
        
        fos.close();
        rbc.close();
		return buffer2;
    }
	
//	 @PostMapping("/api/file/upload")
//	    public String uploadMultipartFile(@RequestParam("file") MultipartFile file) {
//	      try {
//	        String loanDocId = null;
//			// save file to PostgreSQL
//	        LoanDocuments filemode = new LoanDocuments(file.getOriginalFilename(),file.getContentType(),file.getBytes(), loanDocId);
//	        return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
//	    } catch (  Exception e) {
//	      return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
//	    }   
//	 }
	 
//	 @SuppressWarnings("unchecked")
//	@GetMapping("/api/file/{id}")
//	  public String getFile(@PathVariable String accountId) {
//		LoanDocuments fileOptional =  loanDocumentsRepository.findByAccountId(accountId);
//	    
//	return	fileOptional.getFileName();
//	
//	  }
	
//	   @JsonView(View.FileInfo.class)
	   @GetMapping("/api/file/all")
	   public java.util.List<LoanDocuments> getListFiles() {
	    return loanDocumentsRepository.findAll();
	     
	     
	   }
	   
//	   @GetMapping("/api/file/{accountId}")
//		  public ResponseEntity<byte[]> getFile(@PathVariable String id) {
//			  List<LoanDocuments> fileOptional = loanDocumentsRepository.findByAccountId(id);
//		    
//			  	
//		    
//		    return ResponseEntity.status(404).body(null);
//		  }
	   

}



//@GetMapping(value = "/viewDocuments",produces = MediaType.IMAGE_JPEG_VALUE)
//public byte[] getImage(@RequestParam("loanDocId") String loanDocId, @RequestParam("docName") String docName,@RequestBody MultipartFile uploadFile, HttpServletRequest request, HttpServletResponse response ) throws IOException {
////	String tempName = "/download.png";
////	showFlagType = "D/";
//	byte[] b= new byte[0];
//	byte[]c = new byte[0];
//	String filename =" ";
////	String fileName = docName;
//
//LoanDocuments loanDoc = loanDocumentsRepository.getOne(loanDocId,docName);
//
//	    c=  loanDoc.getFile();
//	    if(loanDoc == null)
//	        	
//	   
//	   filename =    loanDocId+docName;
//	   
//	  FileOutputStream fis = new FileOutputStream("D:/uploadedfiles/ram/"+filename);
//	  
//	  fis.write(c);
//
//	 fis.close();
//	  
//	 response.setContentType("application/force-download");
//
////     response.setContentType("application/jpeg; charset=UTF-8");
////	byte[] bytes = loanDoc.getFile();
//
////	byte[] base64 = Base64.getEncoder().encodeToString(bytes);
////	 String url = "https://www.journaldev.com/sitemap.xml";
//	 String url= "file:///D:/uploadedfiles/"+docName;
//	 
//	 
//	 
//        
//	try {
//		
//     //  c= downloadUsingNIO(url, "file:///D:/uploadedfiles/ram"+fileName);
////        file:{"D:/uploadedfiles/ram/sitemap.xml"};
//        
//       b= downloadUsingStream(url, "D:/uploadedfiles/ram/"+filename);
//    }
//	catch (FileNotFoundException e) { 
//           System.out.println("File does not exist"); 
//        } 
//	catch (IOException e) {
//        e.printStackTrace();
//    }
//	
//	
//	
//	return b;
//	
//	
////   byte[] imgFile = new ClassPathResource("D:/uploadedfiles/"+fileName) ;
////   return loanDoc.getFile();
//
//	
//	
////	return bytes;
//	
////	 Boolean documentName = loanDoc.getDisbursementPhotograh();
////	System.out.println("document name*********"+loanDoc);
////	 inputStream = new FileInputStream
//    
//
//    
////    return ResponseEntity
////            .ok()
////            .contentType(MediaType.IMAGE_JPEG)
////            .body(new InputStreamResource(imgFile.getInputStream()));
//}
//
//
//
