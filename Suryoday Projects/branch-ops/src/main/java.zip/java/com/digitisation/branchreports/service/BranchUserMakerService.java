package com.digitisation.branchreports.service;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.model.RepMaster;

public interface BranchUserMakerService {

	public int storeFile(String reportname, String status, String branchname, Date currentdate, MultipartFile file,
			String dataavailable, String dataverified, String filename); // ,String name
	public BranchUserMakerModel addreport(BranchUserMakerModel reportmas);
    public List<BranchUserMakerModel> getreports(BranchUserMakerModel reportmas);
    public int updatechecker(BranchUserMakerModel bkm);
	public int insertdata();
	public List<BranchUserMakerModel> retrievereports(String status,Date startdate,Date lastdate);
	public List<BranchUserMakerModel> allexceptionreport(String status);
}
