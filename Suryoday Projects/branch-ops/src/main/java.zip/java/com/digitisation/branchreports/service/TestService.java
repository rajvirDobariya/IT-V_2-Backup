package com.digitisation.branchreports.service;

import java.util.List;

import com.digitisation.branchreports.model.*;


public interface TestService {

	

	public Address addreport(Address reportmas);


}
