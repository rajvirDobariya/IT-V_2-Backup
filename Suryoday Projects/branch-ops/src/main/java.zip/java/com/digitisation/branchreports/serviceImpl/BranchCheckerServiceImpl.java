package com.digitisation.branchreports.serviceImpl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.BranchChecker;
import com.digitisation.branchreports.model.BranchUserMakerModel;
import com.digitisation.branchreports.repository.BranchCheckerRepository;
import com.digitisation.branchreports.service.BranchCheckerService;

@Service

public class BranchCheckerServiceImpl implements BranchCheckerService {

	@Autowired
	private BranchCheckerRepository branchcheckerrepo;
	
	@Override
	public BranchChecker addreport(BranchChecker reportmas) {
		return branchcheckerrepo.saveAndFlush(reportmas);
	}

	@Override
	public List<BranchUserMakerModel> getreports(BranchUserMakerModel bkm) {

		
		Calendar cal = Calendar.getInstance();
		

		List<String> frequencies = new ArrayList<String>();

		boolean monday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY;
		boolean sunday = cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;

		String valid = "yes";
		int firstday = 1;
		if (valid.equals("yes") && !sunday) {

			if (monday) {

				// weekly and daily reports
				frequencies.add("Weekly");
				frequencies.add("Daily");
			}

			else if (!monday) {

				frequencies.add("Daily");

			}

			else if (monday && firstday == 1) {

				// daily,weekly,monthly
				frequencies.add("Weekly");
				frequencies.add("Daily");
				frequencies.add("Monthly");

			} else if (!monday && firstday == 1) {
				// daily,monthly
				frequencies.add("Daily");
				frequencies.add("Monthly");
			}

		} else if (valid.equals("no") && !sunday) {

		}
	        

		return branchcheckerrepo.getreportschecker(bkm.getStatus(),new Date());

	}

	
	

}
