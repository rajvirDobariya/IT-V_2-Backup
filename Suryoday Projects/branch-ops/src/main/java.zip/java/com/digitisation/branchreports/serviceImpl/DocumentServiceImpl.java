package com.digitisation.branchreports.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;

import com.digitisation.branchreports.model.Branch;
import com.digitisation.branchreports.model.CenterDocumentMaster;
import com.digitisation.branchreports.model.DocumentMaster;
import com.digitisation.branchreports.repository.CenterDocumentRepository;
import com.digitisation.branchreports.repository.DocumentMasterRepository;
import com.digitisation.branchreports.service.DocumentService;

@Service
public class DocumentServiceImpl implements DocumentService {
	
	private DocumentMasterRepository documentRepository;
	
	@Autowired
	public void setDocumentRepository(DocumentMasterRepository documentRepository) {
		this.documentRepository = documentRepository;
	}
	
	private CenterDocumentRepository centerDocumentRepository;

	@Autowired
	public void setCenterDocumentRepository(CenterDocumentRepository centerDocumentRepository) {
		this.centerDocumentRepository = centerDocumentRepository;
	}
	
	@Override
	public List<DocumentMaster> getAllDocuments() {
		return documentRepository.findAll();
	}

	@Override
	public DocumentMaster addDocument(DocumentMaster document) {
//		centerDocumentRepository.saveAndFlush(document);
//		System.out.println("center added");
		return documentRepository.save(document);
		
	}

	@Override
	public Iterable<DocumentMaster> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void  deleteDocument(long documentId) {
		// TODO Auto-generated method stub
		System.out.println("enter "+documentId);
		 documentRepository.deleteById(documentId);
	}

}
