package com.digitisation.branchreports.model;

import java.util.Date;

import javax.annotation.Generated;
import javax.persistence.*;

@Entity
public class HolidayMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public long id;
	
	public String branchname;
	
	@Temporal(TemporalType.DATE)
	public Date holidaydate;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getBranchname() {
		return branchname;
	}
	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}
	public Date getHolidaydate() {
		return holidaydate;
	}
	public void setHolidaydate(Date holidaydate) {
		this.holidaydate = holidaydate;
	}
}
