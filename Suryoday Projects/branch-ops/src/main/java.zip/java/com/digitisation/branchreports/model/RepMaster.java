package com.digitisation.branchreports.model;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
public class RepMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long reportid;
	private String reportextracted;
	private String reportfrequency;
	private String reportname;
	private String reportapplicable;
	
	@Temporal(TemporalType.DATE)
	private Date reportstartdate;
	
	public Date getReportstartdate() {
		return reportstartdate;
	}


	public void setReportstartdate(Date reportstartdate) {
		this.reportstartdate = reportstartdate;
	}


	@Temporal(TemporalType.DATE)
	private Date reportenddate;

	

	public Date getReportenddate() {
		return reportenddate;
	}


	public void setReportenddate(Date reportenddate) {
		this.reportenddate = reportenddate;
	}


	private String branchname;
	
	public int getDeleteflag() {
		return deleteflag;
	}


	public void setDeleteflag(int deleteflag) {
		this.deleteflag = deleteflag;
	}


	@ColumnDefault("1")
	private int deleteflag;
	
	public String getBranchname() {
		return branchname;
	}


	public void setBranchname(String branchname) {
		this.branchname = branchname;
	}


	public String getReportapplicable() {
		return reportapplicable;
	}


	public void setReportapplicable(String reportapplicable) {
		this.reportapplicable = reportapplicable;
	}


	public String getReportextracted() {
		return reportextracted;
	}

	public void setReportextracted(String reportextracted) {
		this.reportextracted = reportextracted;
	}

	
	@ManyToOne(targetEntity = RepMaster.class,fetch = FetchType.LAZY)
	@JsonIgnoreProperties("repmaster")
	private BranchUserMakerModel branchmaker;

	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "branchmaster_id")
	private BranchMaster branchmaster;

	
//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "branchmaster_id")
//	private BranchMaster branchmaster;
//
//	public BranchMaster getBranchmaster() {
//		return branchmaster;
//	}
//
//
//	public void setBranchmaster(BranchMaster branchmaster) {
//		this.branchmaster = branchmaster;
//	}


	public String getReportname() {
		return reportname;
	}

	public long getReportid() {
		return reportid;
	}


	public void setReportid(long reportid) {
		this.reportid = reportid;
	}


	public void setReportname(String reportname) {
		this.reportname = reportname;
	}


	public String getReportfrequency() {
		return reportfrequency;
	}


	public void setReportfrequency(String reportfrequency) {
		this.reportfrequency = reportfrequency;
	}


	public BranchUserMakerModel getBranchmaker() {
		return branchmaker;
	}


	public void setBranchmaker(BranchUserMakerModel branchmaker) {
		this.branchmaker = branchmaker;
	}




	
}
