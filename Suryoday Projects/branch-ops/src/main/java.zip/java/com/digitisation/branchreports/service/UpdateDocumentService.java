package com.digitisation.branchreports.service;

import java.util.List;

import com.digitisation.branchreports.model.DocumentMaster;
import com.digitisation.branchreports.model.UpdateDocument;

public interface UpdateDocumentService {
	
	public List<UpdateDocument> getAllDocuments();

	public UpdateDocument updateDocuments(UpdateDocument updateAccount);
	UpdateDocument getAccountData(String accountNumber);
	 List<UpdateDocument>  getDocumentByAcNo(String updateAccountId);
	// int updateDocumentsData(String updateAccountId, String documentName, boolean selectColumn);
	public int updateDocumentsData(String updateAccountId, String documentName, boolean selectColumn, String status);
	int deleteDocumentById(String updateAccountId);
//	UpdateDocument deleteDocumentById(UpdateDocument updateAccountId);




}
