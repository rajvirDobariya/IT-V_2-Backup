package com.digitisation.branchreports.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.digitisation.branchreports.model.EmployeeDetails;
import com.digitisation.branchreports.model.EmployeeRole;
import com.digitisation.branchreports.repository.EmployeeRoleRepository;
import com.digitisation.branchreports.repository.UserRepository;
import com.digitisation.branchreports.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private EmployeeRoleRepository employeeRoleRepository;

	@Autowired
	public void setUserRepository(UserRepository userRepository) {
		this.userRepository = userRepository;
	}
	
	@Override
	public EmployeeDetails saveEmployeeDetails(EmployeeDetails emp) {
		return userRepository.save(emp);
	}

	@Override
	public EmployeeDetails getEmployeeByEmpCode(String empCode) {
		return userRepository.getEmployeeDetailsByEmpId(empCode);
	}

	@Override
	public List<EmployeeDetails> getAllEmployee() {
		return userRepository.findAll();
	}

	@Override
	public EmployeeRole saveEmployeeRole(EmployeeRole empRole) {
		// TODO Auto-generated method stub
		return employeeRoleRepository.saveAndFlush(empRole);
	}


}
