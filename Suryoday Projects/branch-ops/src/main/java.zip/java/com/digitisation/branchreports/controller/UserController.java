package com.digitisation.branchreports.controller;

import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.digitisation.branchreports.model.EmployeeDetails;
import com.digitisation.branchreports.model.EmployeeRole;
import com.digitisation.branchreports.service.UserService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController {
	
	private UserService userService;

	@Autowired
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	@PostMapping("/getEmptyEmp")
	public EmployeeDetails getEmptyEmp() {
		EmployeeRole roles = new EmployeeRole();
		List<EmployeeRole> roleList = new ArrayList();
		roleList.add(roles);
		EmployeeDetails emp = new EmployeeDetails();
		emp.setRole(roleList);
		
		return emp;
	}
	
	@PostMapping("/getEmpDetails")
	public EmployeeDetails getEmp(@PathParam("empId") String empId) {
		
		return userService.getEmployeeByEmpCode(empId);
	}
	
	@PostMapping("/saveEmployeeDetails")
	public EmployeeDetails saveEmployeeDetails(@RequestBody EmployeeDetails employeeDetails) {
		EmployeeRole empRole = null;
			
		for(int i=0; i<=employeeDetails.getRole().size()-1;i++) {
			empRole = employeeDetails.getRole().get(i);
			userService.saveEmployeeRole(empRole);
		}
	
		
		return userService.saveEmployeeDetails(employeeDetails);
	
	}
	
	@PostMapping("/getAllEmployee")
	public List<EmployeeDetails> getAllEmployee(){
		return userService.getAllEmployee();
	}
	
	
}
