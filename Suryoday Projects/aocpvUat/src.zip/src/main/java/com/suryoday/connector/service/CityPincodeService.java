package com.suryoday.connector.service;

import org.json.JSONObject;

public interface CityPincodeService {

	
	public JSONObject getCityPincode(String cityPincode, JSONObject header);
}
