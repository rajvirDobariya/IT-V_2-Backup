package com.suryoday.aocpv.service;

import org.json.JSONObject;

public interface DmsUploadService {

	public JSONObject dmsupload(long applicationNO, long customerId);
}
