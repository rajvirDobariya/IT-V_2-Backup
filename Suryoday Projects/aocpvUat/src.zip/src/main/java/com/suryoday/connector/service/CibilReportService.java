package com.suryoday.connector.service;

public interface CibilReportService {
	
	public String getCibilReport(String request);
	
	public String getJsonRequest(String jsonString);

}
