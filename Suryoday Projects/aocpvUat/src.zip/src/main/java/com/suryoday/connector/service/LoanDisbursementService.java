package com.suryoday.connector.service;

import org.json.JSONObject;

public interface LoanDisbursementService {
	
	public JSONObject loanDisbursement(JSONObject jSONObject,JSONObject header);

}
