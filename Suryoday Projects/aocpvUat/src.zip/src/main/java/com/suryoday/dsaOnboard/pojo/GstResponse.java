package com.suryoday.dsaOnboard.pojo;

public class GstResponse {

	private String gstNo;
	private String state;
	public String getGstNo() {
		return gstNo;
	}
	public void setGstNo(String gstNo) {
		this.gstNo = gstNo;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
