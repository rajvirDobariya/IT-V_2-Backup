package com.suryoday.familyMember.service;
import org.json.JSONObject;

public interface VoterIdValidationService {

	JSONObject voterID(JSONObject jsonObject, JSONObject header);
	
}
