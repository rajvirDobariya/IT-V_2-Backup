package com.suryoday.aocpv.service;

import org.json.JSONObject;

public interface GetSavingDetailsService {

	JSONObject getDetails(JSONObject request, JSONObject header);

}
