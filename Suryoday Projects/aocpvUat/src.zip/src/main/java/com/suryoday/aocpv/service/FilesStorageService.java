package com.suryoday.aocpv.service;

import org.springframework.web.multipart.MultipartFile;

import com.suryoday.aocpv.pojo.FileDB;


import java.util.stream.Stream;

import org.springframework.stereotype.Service;


@Service
public interface FilesStorageService {
	
	
	
	  
	  
	  public FileDB store(MultipartFile file);
	  
		  public FileDB getFile(String id);
		  
		  
		  public Stream<FileDB> getAllFiles();

}
