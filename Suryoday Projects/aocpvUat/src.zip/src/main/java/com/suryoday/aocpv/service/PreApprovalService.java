package com.suryoday.aocpv.service;

import org.json.JSONArray;
import org.json.JSONObject;

public interface PreApprovalService {

	
	JSONObject writeExcel(JSONArray json);
}
