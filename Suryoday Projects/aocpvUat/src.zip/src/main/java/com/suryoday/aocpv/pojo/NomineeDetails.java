package com.suryoday.aocpv.pojo;

public class NomineeDetails {
private String name;
private String guardianRelationship;
private String GuardianName;
private String dob;
private String nomineeAge;
private String guardianAge;
private String address_Line1;
private String address_Line2;
private String address_Line3;
private String pincode;
private String district;
private String city;
private String country;
private String state;
private String nomineeRelationship;
private String latitude;
private String longitude;

public String getLatitude() {
	return latitude;
}
public void setLatitude(String latitude) {
	this.latitude = latitude;
}
public String getLongitude() {
	return longitude;
}
public void setLongitude(String longitude) {
	this.longitude = longitude;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getNomineeAge() {
	return nomineeAge;
}
public void setNomineeAge(String nomineeAge) {
	this.nomineeAge = nomineeAge;
}
public String getGuardianRelationship() {
	return guardianRelationship;
}
public void setGuardianRelationship(String guardianRelationship) {
	this.guardianRelationship = guardianRelationship;
}
public String getNomineeRelationship() {
	return nomineeRelationship;
}
public void setNomineeRelationship(String nomineeRelationship) {
	this.nomineeRelationship = nomineeRelationship;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public String getGuardianName() {
	return GuardianName;
}
public void setGuardianName(String guardianName) {
	GuardianName = guardianName;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getGuardianAge() {
	return guardianAge;
}
public void setGuardianAge(String guardianAge) {
	this.guardianAge = guardianAge;
}
public String getAddress_Line1() {
	return address_Line1;
}
public void setAddress_Line1(String address_Line1) {
	this.address_Line1 = address_Line1;
}
public String getAddress_Line2() {
	return address_Line2;
}
public void setAddress_Line2(String address_Line2) {
	this.address_Line2 = address_Line2;
}
public String getAddress_Line3() {
	return address_Line3;
}
public void setAddress_Line3(String address_Line3) {
	this.address_Line3 = address_Line3;
}
public String getPincode() {
	return pincode;
}
public void setPincode(String pincode) {
	this.pincode = pincode;
}
public String getDistrict() {
	return district;
}
public void setDistrict(String district) {
	this.district = district;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}


}
