package com.suryoday.connector.service;

import org.json.JSONObject;

public interface EMICalculatorService {
	
	public JSONObject EMICalculator(JSONObject jSONObject,JSONObject header);

}
