package com.suryoday.connector.service;

import org.json.JSONObject;

public interface CustomerDetailsService {
	
	public JSONObject fetchbycustomerid(JSONObject jSONObject, JSONObject header);

}
