package com.suryoday.aocpv.service;

import org.json.JSONObject;

import com.suryoday.aocpv.pojo.AocpvLastLogin;

public interface AocpvLastLoginService {

	void save(AocpvLastLogin aocpvLastLogin);

}
