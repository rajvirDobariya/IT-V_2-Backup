package com.suryoday.hastakshar.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.suryoday.hastakshar.service.ReqStatusService;

@RestController
@RequestMapping("/hastakshar")
public class SaveHastRequestData {

	@Autowired
	ReqStatusService reqstatusservice;
	private static Logger logger = LoggerFactory.getLogger(SaveHastRequestData.class);

	@PostMapping(value = "/saveNewRequest", produces = "application/json")
	public ResponseEntity<Object> saveNewRequest(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONObject getResponse = reqstatusservice.saveNewRequestData(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
//		return null;
	}

	@PostMapping(value = "/fetchTopten", produces = "application/json")
	public ResponseEntity<Object> fetchTopten(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONArray getResponse = reqstatusservice.fetchList(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/fetchBySearch", produces = "application/json")
	public ResponseEntity<Object> fetchBySearch(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONArray getResponse = reqstatusservice.fetchBySearch(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/fetchByDate", produces = "application/json")
	public ResponseEntity<Object> fetchByDate(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONArray getResponse = reqstatusservice.fetchByDate(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/fetchByStatus", produces = "application/json")
	public ResponseEntity<Object> fetchByStatus(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONArray getResponse = reqstatusservice.fetchByStatus(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/updateStatus", produces = "application/json")
	public ResponseEntity<Object> updateStatus(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONObject getResponse = reqstatusservice.updateStatus(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/fetchUserLog", produces = "application/json")
	public ResponseEntity<Object> fetchUserLog(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONArray getResponse = reqstatusservice.fetchUserLog(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/saveAttachment", produces = "application/json")
	public ResponseEntity<Object> saveAttachment(@RequestParam List<MultipartFile> files,
			@RequestParam("Data") String requestBody, HttpServletRequest req) {

		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONObject getResponse = reqstatusservice.saveAttachment(jsonRequest, files);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
//		return null;
	}

//	@PostMapping(value = "/saveAttachment", produces = "application/json")
//	public ResponseEntity<Object> saveAttachment(@RequestParam List<MultipartFile> files,
//			@RequestParam("Data") String requestBody) {
//		System.out.println(files.size());
//		System.out.println(requestBody);
//		return null;
//	}

	@PostMapping(value = "/fetchAttachment", produces = "application/json")
	public ResponseEntity<Object> fetchAttachment(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONObject response = reqstatusservice.fetchAttachment(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", response);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/fetchStatusByEmpID", produces = "application/json")
	public ResponseEntity<Object> fetchStatusByEmpID(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONArray getResponse = reqstatusservice.fetchStatusByEmpID(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/reAssignApprover", produces = "application/json")
	public ResponseEntity<Object> reAssignApprover(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONObject getResponse = reqstatusservice.reAssignApprover(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}

	@PostMapping(value = "/getApprovalOfProxy", produces = "application/json")
	public ResponseEntity<Object> getApprovalOfProxy(@RequestBody String requestBody, HttpServletRequest req) {
		JSONObject jsonRequest = new JSONObject(requestBody);
		JSONObject getResponse = reqstatusservice.getApprovalOfProxy(jsonRequest);
		JSONObject outerData = new JSONObject();
		outerData.put("Data", getResponse);
		if (!outerData.equals(null)) {
			logger.debug("Main Response : " + outerData.toString());
			return new ResponseEntity<>(outerData.toString(), HttpStatus.OK);
		} else {
			logger.debug("GATEWAY_TIMEOUT");
			return new ResponseEntity<Object>("timeout", HttpStatus.GATEWAY_TIMEOUT);
		}
	}
}