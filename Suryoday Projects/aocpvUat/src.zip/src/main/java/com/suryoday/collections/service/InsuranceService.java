package com.suryoday.collections.service;

public interface InsuranceService {

	String calculateEmi(double amountIndouble, String productCode, String bankName, String tenure);

}
