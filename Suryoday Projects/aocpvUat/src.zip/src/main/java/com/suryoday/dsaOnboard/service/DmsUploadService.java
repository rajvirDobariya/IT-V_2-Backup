package com.suryoday.dsaOnboard.service;

import java.io.IOException;

import org.json.JSONObject;

public interface DmsUploadService {

	
	public JSONObject dmsUpload(String applicationNo, String dsaCode);
}
