package com.suryoday.dsaOnboard.service;

import org.json.JSONObject;

public interface DsaOnBoardGstDetailsService {

	JSONObject gstAuthentication(JSONObject jsonObject, JSONObject header);

}
