package com.suryoday.dsaOnboard.pojo;

public class SalesManagerFeedbackResponse {

		private String placeOfVisit;
		private String servicesOffered;
		private String recommend;
		private String salesManagerRemarks;
		
		public String getPlaceOfVisit() {
			return placeOfVisit;
		}
		public void setPlaceOfVisit(String placeOfVisit) {
			this.placeOfVisit = placeOfVisit;
		}
		public String getServicesOffered() {
			return servicesOffered;
		}
		public void setServicesOffered(String servicesOffered) {
			this.servicesOffered = servicesOffered;
		}
		public String getRecommend() {
			return recommend;
		}
		public void setRecommend(String recommend) {
			this.recommend = recommend;
		}
		public String getSalesManagerRemarks() {
			return salesManagerRemarks;
		}
		public void setSalesManagerRemarks(String salesManagerRemarks) {
			this.salesManagerRemarks = salesManagerRemarks;
		}
		
}
