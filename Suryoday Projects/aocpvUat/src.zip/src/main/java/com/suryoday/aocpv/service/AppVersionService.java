package com.suryoday.aocpv.service;

import com.suryoday.aocpv.pojo.AppVersion;

public interface AppVersionService {

	AppVersion findVersion();

}
