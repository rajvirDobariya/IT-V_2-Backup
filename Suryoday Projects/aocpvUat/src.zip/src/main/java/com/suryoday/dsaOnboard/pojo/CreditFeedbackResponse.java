package com.suryoday.dsaOnboard.pojo;

public class CreditFeedbackResponse{
	
		private String status;
		private String feedback;
		private String updatedDate;
		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getFeedback() {
			return feedback;
		}
		public void setFeedback(String feedback) {
			this.feedback = feedback;
		}
		public String getUpdatedDate() {
			return updatedDate;
		}
		public void setUpdatedDate(String updatedDate) {
			this.updatedDate = updatedDate;
		}
		
		
		
		
		
		
}
