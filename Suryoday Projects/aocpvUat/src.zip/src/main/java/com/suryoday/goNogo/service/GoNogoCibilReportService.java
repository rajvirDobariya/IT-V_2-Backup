package com.suryoday.goNogo.service;

import org.json.JSONObject;

public interface GoNogoCibilReportService {

	JSONObject getCibilReport(JSONObject jsonObject, JSONObject header);

}
