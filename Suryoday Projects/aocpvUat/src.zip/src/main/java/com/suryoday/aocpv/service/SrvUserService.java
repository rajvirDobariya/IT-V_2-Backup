package com.suryoday.aocpv.service;

import org.json.JSONObject;

public interface SrvUserService {

	JSONObject login();

}
