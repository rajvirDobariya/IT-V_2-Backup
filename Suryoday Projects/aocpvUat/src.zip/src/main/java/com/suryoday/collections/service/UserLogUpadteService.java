package com.suryoday.collections.service;

import com.suryoday.collections.pojo.UserlogUpdate;

public interface UserLogUpadteService {
	
	String userLogUpdatedSave(UserlogUpdate userLogUpadte);

}
