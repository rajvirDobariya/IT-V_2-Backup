package com.suryoday.aocpv.service;

import org.json.JSONObject;

public interface CustomerService {

	JSONObject getData(JSONObject jsonObject, JSONObject header);

}
