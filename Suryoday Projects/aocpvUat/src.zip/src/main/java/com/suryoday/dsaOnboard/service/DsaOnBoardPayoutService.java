package com.suryoday.dsaOnboard.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Component;

import com.suryoday.dsaOnboard.pojo.PayoutSchemeMaster;

@Component
public interface DsaOnBoardPayoutService {

	PayoutSchemeMaster fetchByProductAndAgency(String product, String agencyType);

	String fetchBySchemeCode(String schemeCode) throws IOException;

}
