package com.suryoday.aocpv.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.suryoday.aocpv.pojo.AocpvLoanCreation;

@Component
public interface DisbursementService {

	AocpvLoanCreation fetchDisbursementStatus(long applicationNo);

}
