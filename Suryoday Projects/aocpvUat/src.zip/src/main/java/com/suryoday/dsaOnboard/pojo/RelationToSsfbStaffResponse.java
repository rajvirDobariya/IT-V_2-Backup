package com.suryoday.dsaOnboard.pojo;

public class RelationToSsfbStaffResponse {
	private String id;
	private String relatedToSsfbStaff;
	private String nameOfStaff;
	private String empId;
	private String mobile;
	private String relationWithStaff;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRelatedToSsfbStaff() {
		return relatedToSsfbStaff;
	}
	public void setRelatedToSsfbStaff(String relatedToSsfbStaff) {
		this.relatedToSsfbStaff = relatedToSsfbStaff;
	}
	public String getNameOfStaff() {
		return nameOfStaff;
	}
	public void setNameOfStaff(String nameOfStaff) {
		this.nameOfStaff = nameOfStaff;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getRelationWithStaff() {
		return relationWithStaff;
	}
	public void setRelationWithStaff(String relationWithStaff) {
		this.relationWithStaff = relationWithStaff;
	}
	
}
