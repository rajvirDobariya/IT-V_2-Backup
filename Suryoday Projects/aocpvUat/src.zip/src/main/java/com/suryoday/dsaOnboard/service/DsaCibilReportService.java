package com.suryoday.dsaOnboard.service;

import org.json.JSONObject;

public interface DsaCibilReportService {

	JSONObject getCibilReport(JSONObject jsonObject, JSONObject header);

}
