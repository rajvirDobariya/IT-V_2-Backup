package com.suryoday.dsaOnboard.pojo;

public class BlackListInfo {
	private String blacklistedFiType;
	private String blacklistedFiName;
	
	public String getBlacklistedFiType() {
		return blacklistedFiType;
	}
	public void setBlacklistedFiType(String blacklistedFiType) {
		this.blacklistedFiType = blacklistedFiType;
	}
	public String getBlacklistedFiName() {
		return blacklistedFiName;
	}
	public void setBlacklistedFiName(String blacklistedFiName) {
		this.blacklistedFiName = blacklistedFiName;
	}

}
